#!/bin/bash

# Monitoring Script for MQTT Dashboard
# This script provides monitoring and debugging commands

set -e

NAMESPACE="kalimaya-dashboard"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to show overview
show_overview() {
    log_info "=== Kalimaya Sensor Dashboard Overview ==="
    echo ""
    
    echo "📦 Namespace Status:"
    kubectl get namespace ${NAMESPACE} -o wide || log_warning "Namespace not found"
    echo ""
    
    echo "🚀 Deployments:"
    kubectl get deployments -n ${NAMESPACE} -o wide
    echo ""
    
    echo "🏃 Pods Status:"
    kubectl get pods -n ${NAMESPACE} -o wide
    echo ""
    
    echo "🔗 Services:"
    kubectl get services -n ${NAMESPACE} -o wide
    echo ""
    
    echo "🌐 Ingress:"
    kubectl get ingress -n ${NAMESPACE} -o wide
    echo ""
    
    echo "📈 HPA Status:"
    kubectl get hpa -n ${NAMESPACE} -o wide
    echo ""
    
    echo "💾 Storage:"
    kubectl get pvc -n ${NAMESPACE} -o wide
    echo ""
}

# Function to show resource usage
show_resources() {
    log_info "=== Resource Usage ==="
    echo ""
    
    echo "📊 Pod Resource Usage:"
    kubectl top pods -n ${NAMESPACE} --containers=true 2>/dev/null || log_warning "Metrics server not available"
    echo ""
    
    echo "🖥️ Node Resource Usage:"
    kubectl top nodes 2>/dev/null || log_warning "Metrics server not available"
    echo ""
}

# Function to show logs
show_logs() {
    local component=$1
    
    case "$component" in
        "app")
            log_info "Showing logs for MQTT Dashboard application..."
            kubectl logs -f deployment/mqtt-dashboard -n ${NAMESPACE} --tail=100
            ;;
        "redis")
            log_info "Showing logs for Redis..."
            kubectl logs -f deployment/redis -n ${NAMESPACE} --tail=50
            ;;
        "mosquitto")
            log_info "Showing logs for Mosquitto..."
            kubectl logs -f deployment/mosquitto -n ${NAMESPACE} --tail=50
            ;;
        "all")
            log_info "Showing logs for all components..."
            kubectl logs -f -l app=mqtt-dashboard -n ${NAMESPACE} --tail=50
            ;;
        *)
            log_error "Unknown component: $component"
            echo "Available components: app, redis, mosquitto, all"
            exit 1
            ;;
    esac
}

# Function to describe resources
describe_resource() {
    local resource_type=$1
    local resource_name=$2
    
    if [ -z "$resource_name" ]; then
        log_info "Available $resource_type resources:"
        kubectl get $resource_type -n ${NAMESPACE}
        return
    fi
    
    log_info "Describing $resource_type/$resource_name..."
    kubectl describe $resource_type $resource_name -n ${NAMESPACE}
}

# Function to exec into pod
exec_pod() {
    local component=$1
    local command=${2:-"sh"}
    
    local pod_name=$(kubectl get pods -n ${NAMESPACE} -l component=$component -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
    
    if [ -z "$pod_name" ]; then
        log_error "No pod found for component: $component"
        return 1
    fi
    
    log_info "Executing command in pod: $pod_name"
    kubectl exec -it $pod_name -n ${NAMESPACE} -- $command
}

# Function to check health
check_health() {
    log_info "=== Health Check ==="
    echo ""
    
    # Check if pods are running
    local app_pods=$(kubectl get pods -n ${NAMESPACE} -l component=app --field-selector=status.phase=Running --no-headers | wc -l)
    local redis_pods=$(kubectl get pods -n ${NAMESPACE} -l component=redis --field-selector=status.phase=Running --no-headers | wc -l)
    local mosquitto_pods=$(kubectl get pods -n ${NAMESPACE} -l component=mosquitto --field-selector=status.phase=Running --no-headers | wc -l)
    
    echo "🟢 App Pods Running: $app_pods"
    echo "🟢 Redis Pods Running: $redis_pods"
    echo "🟢 Mosquitto Pods Running: $mosquitto_pods"
    echo ""
    
    # Check service endpoints
    echo "🔗 Service Endpoints:"
    kubectl get endpoints -n ${NAMESPACE}
    echo ""
    
    # Check recent events
    echo "📅 Recent Events:"
    kubectl get events -n ${NAMESPACE} --sort-by='.lastTimestamp' | tail -10
    echo ""
}

# Function to scale deployment
scale_deployment() {
    local deployment=$1
    local replicas=$2
    
    if [ -z "$deployment" ] || [ -z "$replicas" ]; then
        log_error "Usage: $0 scale <deployment> <replicas>"
        echo "Available deployments: mqtt-dashboard, redis, mosquitto"
        return 1
    fi
    
    log_info "Scaling deployment $deployment to $replicas replicas..."
    kubectl scale deployment $deployment --replicas=$replicas -n ${NAMESPACE}
    
    log_info "Waiting for scale to complete..."
    kubectl rollout status deployment/$deployment -n ${NAMESPACE} --timeout=300s
    log_success "Scale completed successfully"
}

# Function to restart deployment
restart_deployment() {
    local deployment=$1
    
    if [ -z "$deployment" ]; then
        log_error "Usage: $0 restart <deployment>"
        echo "Available deployments: mqtt-dashboard, redis, mosquitto"
        return 1
    fi
    
    log_info "Restarting deployment $deployment..."
    kubectl rollout restart deployment/$deployment -n ${NAMESPACE}
    
    log_info "Waiting for restart to complete..."
    kubectl rollout status deployment/$deployment -n ${NAMESPACE} --timeout=300s
    log_success "Restart completed successfully"
}

# Main menu
case "$1" in
    "overview"|"")
        show_overview
        ;;
    "resources")
        show_resources
        ;;
    "logs")
        show_logs $2
        ;;
    "describe")
        describe_resource $2 $3
        ;;
    "exec")
        exec_pod $2 $3
        ;;
    "health")
        check_health
        ;;
    "scale")
        scale_deployment $2 $3
        ;;
    "restart")
        restart_deployment $2
        ;;
    *)
        echo "MQTT Dashboard Monitoring Script"
        echo ""
        echo "Usage: $0 [COMMAND] [OPTIONS]"
        echo ""
        echo "Commands:"
        echo "  overview                 - Show cluster overview (default)"
        echo "  resources                - Show resource usage"
        echo "  logs [component]         - Show logs (app|redis|mosquitto|all)"
        echo "  describe <type> [name]   - Describe resource"
        echo "  exec <component> [cmd]   - Execute command in pod"
        echo "  health                   - Check health status"
        echo "  scale <deployment> <n>   - Scale deployment"
        echo "  restart <deployment>     - Restart deployment"
        echo ""
        echo "Examples:"
        echo "  $0 overview"
        echo "  $0 logs app"
        echo "  $0 describe pod mqtt-dashboard-xxx"
        echo "  $0 exec app sh"
        echo "  $0 scale mqtt-dashboard 5"
        echo "  $0 restart redis"
        exit 1
        ;;
esac