#!/bin/bash

# Port Forwarding Script for MQTT Dashboard
# This script sets up port forwarding for local development

set -e

NAMESPACE="kalimaya-dashboard"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Function to port forward main app
forward_app() {
    log_info "Setting up port forward for main application (localhost:3000)..."
    kubectl port-forward service/mqtt-dashboard-service 3000:80 -n ${NAMESPACE} &
    APP_PID=$!
    log_success "Application forwarded to http://localhost:3000 (PID: $APP_PID)"
}

# Function to port forward Redis
forward_redis() {
    log_info "Setting up port forward for Redis (localhost:6379)..."
    kubectl port-forward service/redis-service 6379:6379 -n ${NAMESPACE} &
    REDIS_PID=$!
    log_success "Redis forwarded to localhost:6379 (PID: $REDIS_PID)"
}

# Function to port forward Mosquitto
forward_mosquitto() {
    log_info "Setting up port forward for Mosquitto MQTT (localhost:1883)..."
    kubectl port-forward service/mosquitto-service 1883:1883 -n ${NAMESPACE} &
    MQTT_PID=$!
    log_success "Mosquitto MQTT forwarded to localhost:1883 (PID: $MQTT_PID)"
    
    log_info "Setting up port forward for Mosquitto WebSocket (localhost:9001)..."
    kubectl port-forward service/mosquitto-service 9001:9001 -n ${NAMESPACE} &
    WS_PID=$!
    log_success "Mosquitto WebSocket forwarded to localhost:9001 (PID: $WS_PID)"
}

# Function to cleanup
cleanup() {
    log_info "Cleaning up port forwards..."
    jobs -p | xargs -r kill
    log_success "All port forwards stopped"
}

# Trap to cleanup on exit
trap cleanup EXIT

# Main execution
case "$1" in
    "app")
        forward_app
        ;;
    "redis")
        forward_redis
        ;;
    "mqtt")
        forward_mosquitto
        ;;
    "all")
        forward_app
        forward_redis
        forward_mosquitto
        ;;
    "cleanup")
        cleanup
        exit 0
        ;;
    "")
        log_info "Forwarding all services..."
        forward_app
        forward_redis
        forward_mosquitto
        ;;
    *)
        echo "Usage: $0 [app|redis|mqtt|all|cleanup]"
        echo ""
        echo "Options:"
        echo "  app      - Forward main application only"
        echo "  redis    - Forward Redis only"
        echo "  mqtt     - Forward Mosquitto (MQTT + WebSocket) only"
        echo "  all      - Forward all services (default)"
        echo "  cleanup  - Stop all port forwards"
        exit 1
        ;;
esac

log_info "Port forwarding is active. Press Ctrl+C to stop."
log_info "Access the application at: http://localhost:3000"

# Keep script running
wait