#!/bin/bash

# MQTT Dashboard Kubernetes Deployment Script
# This script deploys the MQTT Dashboard to a Kubernetes cluster

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
NAMESPACE="kalimaya-dashboard"
DOCKER_IMAGE="kalimaya-dashboard"
DOCKER_TAG="latest"
REGISTRY="" # Set your registry here, e.g., "your-registry.com/"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if kubectl is available
check_kubectl() {
    if ! command -v kubectl &> /dev/null; then
        log_error "kubectl is not installed or not in PATH"
        exit 1
    fi
    
    if ! kubectl cluster-info &> /dev/null; then
        log_error "Cannot connect to Kubernetes cluster"
        exit 1
    fi
    
    log_success "kubectl is available and cluster is accessible"
}

# Build and push Docker image
build_and_push() {
    log_info "Building Docker image..."
    
    # Build the image
    docker build -t ${DOCKER_IMAGE}:${DOCKER_TAG} .
    
    if [ ! -z "$REGISTRY" ]; then
        # Tag for registry
        docker tag ${DOCKER_IMAGE}:${DOCKER_TAG} ${REGISTRY}${DOCKER_IMAGE}:${DOCKER_TAG}
        
        log_info "Pushing image to registry..."
        docker push ${REGISTRY}${DOCKER_IMAGE}:${DOCKER_TAG}
        
        # Update image name in deployment files
        sed -i "s|image: ${DOCKER_IMAGE}:latest|image: ${REGISTRY}${DOCKER_IMAGE}:${DOCKER_TAG}|g" deployment/app.yaml
    fi
    
    log_success "Docker image built and pushed successfully"
}

# Create namespace
create_namespace() {
    log_info "Creating namespace..."
    kubectl apply -f namespace/namespace.yaml
    log_success "Namespace created successfully"
}

# Apply configurations
apply_configs() {
    log_info " applying configurations..."
    
    # Apply ConfigMaps and Secrets
    kubectl apply -f configmap/configmap.yaml
    kubectl apply -f configmap/secrets.yaml
    
    log_success "Configurations applied successfully"
}

# Create storage
create_storage() {
    log_info "Creating persistent volumes..."
    kubectl apply -f deployment/pv.yaml
    log_success "Persistent volumes created successfully"
}

# Deploy applications
deploy_apps() {
    log_info "Deploying applications..."
    
    # Deploy Redis
    kubectl apply -f deployment/redis.yaml
    log_info "Waiting for Redis to be ready..."
    kubectl wait --for=condition=available --timeout=300s deployment/redis -n ${NAMESPACE}
    
    # Deploy Mosquitto
    kubectl apply -f deployment/mosquitto.yaml
    log_info "Waiting for Mosquitto to be ready..."
    kubectl wait --for=condition=available --timeout=300s deployment/mosquitto -n ${NAMESPACE}
    
    # Deploy main application
    kubectl apply -f deployment/app.yaml
    log_info "Waiting for main application to be ready..."
    kubectl wait --for=condition=available --timeout=300s deployment/mqtt-dashboard -n ${NAMESPACE}
    
    log_success "All applications deployed successfully"
}

# Create services
create_services() {
    log_info "Creating services..."
    kubectl apply -f service/services.yaml
    log_success "Services created successfully"
}

# Create ingress
create_ingress() {
    log_info "Creating ingress..."
    kubectl apply -f ingress/ingress.yaml
    log_success "Ingress created successfully"
}

# Setup autoscaling
setup_autoscaling() {
    log_info "Setting up autoscaling..."
    kubectl apply -f deployment/hpa.yaml
    log_success "Autoscaling configured successfully"
}

# Verify deployment
verify_deployment() {
    log_info "Verifying deployment..."
    
    # Check all pods are running
    kubectl get pods -n ${NAMESPACE}
    
    # Check services
    kubectl get services -n ${NAMESPACE}
    
    # Check ingress
    kubectl get ingress -n ${NAMESPACE}
    
    # Check HPA
    kubectl get hpa -n ${NAMESPACE}
    
    log_success "Deployment verification completed"
}

# Show access information
show_access_info() {
    log_info "Access Information:"
    echo "==================================="
    
    # Get ingress URL
    INGRESS_URL=$(kubectl get ingress mqtt-dashboard-ingress -n ${NAMESPACE} -o jsonpath='{.spec.rules[0].host}' 2>/dev/null || echo "Not available")
    if [ "$INGRESS_URL" != "Not available" ]; then
        echo "🌐 Application URL: https://$INGRESS_URL"
    fi
    
    # Get NodePort (if available)
    NODEPORT=$(kubectl get service mqtt-dashboard-nodeport -n ${NAMESPACE} -o jsonpath='{.spec.ports[0].nodePort}' 2>/dev/null || echo "")
    if [ ! -z "$NODEPORT" ]; then
        NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}' 2>/dev/null || echo "localhost")
        echo "🔗 NodePort URL: http://$NODE_IP:$NODEPORT"
    fi
    
    # Get LoadBalancer IP (if available)
    LB_IP=$(kubectl get service mqtt-dashboard-lb -n ${NAMESPACE} -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "")
    if [ ! -z "$LB_IP" ]; then
        echo "⚖️ LoadBalancer URL: http://$LB_IP"
    fi
    
    echo "==================================="
    echo "📊 To check logs: kubectl logs -f deployment/mqtt-dashboard -n ${NAMESPACE}"
    echo "🔍 To check status: kubectl get all -n ${NAMESPACE}"
    echo "📈 To scale: kubectl scale deployment mqtt-dashboard --replicas=5 -n ${NAMESPACE}"
}

# Cleanup function
cleanup() {
    log_warning "Cleaning up deployment..."
    kubectl delete namespace ${NAMESPACE} --ignore-not-found=true
    log_success "Cleanup completed"
}

# Main deployment function
deploy() {
    log_info "Starting Kalimaya Sensor Dashboard deployment..."
    
    check_kubectl
    
    if [ "$1" == "--build" ]; then
        build_and_push
    fi
    
    create_namespace
    apply_configs
    create_storage
    deploy_apps
    create_services
    create_ingress
    setup_autoscaling
    verify_deployment
    show_access_info
    
    log_success "🎉 Kalimaya Sensor Dashboard deployed successfully!"
}

# Show usage
usage() {
    echo "Kalimaya Sensor Dashboard Deployment Script"
    echo ""
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  --build     Build and push Docker image before deployment"
    echo "  --cleanup   Delete the entire deployment"
    echo "  --help      Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 --build          # Build image and deploy"
    echo "  $0                  # Deploy existing image"
    echo "  $0 --cleanup        # Clean up deployment"
}

# Main script logic
case "$1" in
    --build)
        deploy --build
        ;;
    --cleanup)
        cleanup
        ;;
    --help)
        usage
        ;;
    "")
        deploy
        ;;
    *)
        log_error "Unknown option: $1"
        usage
        exit 1
        ;;
esac