'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useSession, signIn } from 'next-auth/react';
import { useMQTTStore } from '@/lib/stores/mqtt-store';
import { Header } from '@/components/mqtt/Header';
import { SensorList } from '@/components/mqtt/SensorList';
import { SensorChart } from '@/components/mqtt/SensorChart';
import { AdvancedChart } from '@/components/mqtt/AdvancedChart';
import { AlertPanel } from '@/components/mqtt/AlertPanel';
import { SettingsPanel } from '@/components/mqtt/SettingsPanel';
import { Notifications } from '@/components/mqtt/Notifications';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ChartLine, 
  Satellite, 
  Activity, 
  Download,
  RefreshCw,
  Grid3X3,
  List,
  AlertTriangle,
  BarChart3,
  Database,
  Settings,
  Shield,
  Users,
  FileText,
  Globe
} from 'lucide-react';

export default function Home() {
  const { data: session, status } = useSession();
  const [isLoading, setIsLoading] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [expandedChart, setExpandedChart] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  
  const { 
    sensors, 
    selectedSensor, 
    clearAllData, 
    exportData,
    notifications,
    connectionStatus 
  } = useMQTTStore();
  
  const sensorArray = Array.from(sensors.values());
  const activeSensorCount = sensorArray.filter(s => s.isActive).length;
  const unreadNotifications = notifications.filter(n => !n.isRead).length;
  
  // Fetch active alerts count
  const [activeAlertsCount, setActiveAlertsCount] = useState(0);
  
  useEffect(() => {
    const fetchAlertsCount = async () => {
      try {
        const response = await fetch('/api/alerts');
        if (response.ok) {
          const alerts = await response.json();
          const activeCount = alerts.filter((alert: any) => alert.status === 'ACTIVE').length;
          setActiveAlertsCount(activeCount);
        }
      } catch (error) {
        console.error('Error fetching alerts count:', error);
      }
    };
    
    if (session) {
      fetchAlertsCount();
      const interval = setInterval(fetchAlertsCount, 30000); // Update every 30 seconds
      return () => clearInterval(interval);
    }
  }, [session]);

  // Auto-hide expanded chart when sensor is deselected
  useEffect(() => {
    if (!selectedSensor) {
      setExpandedChart(null);
    }
  }, [selectedSensor]);

  // Handle chart expand
  const handleChartExpand = (sensorName: string) => {
    setExpandedChart(expandedChart === sensorName ? null : sensorName);
  };

  // Handle sensor delete
  const handleSensorDelete = (sensorName: string) => {
    const sensors = useMQTTStore.getState().sensors;
    sensors.delete(sensorName);
    useMQTTStore.setState({ sensors: new Map(sensors) });
    
    if (expandedChart === sensorName) {
      setExpandedChart(null);
    }
  };

  // Handle export all data
  const handleExportAll = () => {
    const data = exportData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `mqtt-dashboard-export-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Authentication loading
  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full"
        />
        <p className="ml-4 text-gray-600">Loading authentication...</p>
      </div>
    );
  }

  // Debug: Show session status
  console.log('Session status:', status);
  console.log('Session data:', session);

  // Not authenticated
  if (!session) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full"
        >
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-blue-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Kalimaya Sensor Dashboard</h1>
            <p className="text-gray-600">Enterprise-grade sensor monitoring platform</p>
          </div>
          
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              const email = (e.target as any).email.value;
              const password = (e.target as any).password.value;
              
              console.log('Attempting login with:', email);
              setIsLoading(true);
              try {
                const result = await signIn('credentials', {
                  email,
                  password,
                  redirect: false
                });
                
                console.log('Sign in result:', result);
                
                if (result?.ok) {
                  console.log('Login successful, reloading page...');
                  window.location.reload();
                } else {
                  console.error('Login failed:', result?.error);
                  alert('Login failed: Invalid credentials');
                }
              } catch (error) {
                console.error('Login error:', error);
                alert('Login error: Please try again');
              } finally {
                setIsLoading(false);
              }
            }}
            className="space-y-4"
          >
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input
                type="email"
                name="email"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="admin@example.com"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <input
                type="password"
                name="password"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="••••••••"
              />
            </div>
            
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Signing In...' : 'Sign In'}
            </button>
          </form>
          
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600 text-center">
              Demo credentials: admin@example.com / admin123
            </p>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <Header />
      <Notifications />
      <SettingsPanel />
      
      <main className="container mx-auto px-4 py-6">
        {/* Enhanced Dashboard Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6"
        >
          <Card className="bg-white/50 backdrop-blur-sm border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Sensors</p>
                  <p className="text-2xl font-bold text-gray-900">{sensorArray.length}</p>
                </div>
                <Satellite className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/50 backdrop-blur-sm border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Sensors</p>
                  <p className="text-2xl font-bold text-gray-900">{activeSensorCount}</p>
                </div>
                <Activity className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/50 backdrop-blur-sm border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Data Points</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {sensorArray.reduce((acc, s) => acc + s.data.length, 0)}
                  </p>
                </div>
                <Database className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/50 backdrop-blur-sm border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Alerts</p>
                  <p className="text-2xl font-bold text-gray-900">{activeAlertsCount}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/50 backdrop-blur-sm border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Notifications</p>
                  <p className="text-2xl font-bold text-gray-900">{unreadNotifications}</p>
                </div>
                <div className="relative">
                  <FileText className="w-8 h-8 text-indigo-500" />
                  {unreadNotifications > 0 && (
                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full" />
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Main Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-6">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <ChartLine className="w-4 h-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="alerts" className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Alerts
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Reports
            </TabsTrigger>
            <TabsTrigger value="admin" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Admin
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* Action Bar */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
              className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between"
            >
              <div className="flex gap-2">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="flex items-center gap-2"
                >
                  <Grid3X3 className="w-4 h-4" />
                  Grid
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className="flex items-center gap-2"
                >
                  <List className="w-4 h-4" />
                  List
                </Button>
              </div>
              
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleExportAll}
                  className="flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  Export All
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearAllData}
                  className="flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  Clear All
                </Button>
              </div>
            </motion.div>

            {/* Main Content */}
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Sensor List */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 0.2 }}
                className="lg:col-span-1"
              >
                <SensorList />
              </motion.div>

              {/* Charts Area */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 0.3 }}
                className="lg:col-span-3"
              >
                <AnimatePresence mode="popLayout">
                  {sensorArray.length === 0 ? (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="flex flex-col items-center justify-center h-96 text-center"
                    >
                      <div className="p-8 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/20 max-w-md">
                        <Satellite className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                        <h3 className="text-xl font-semibold text-gray-700 mb-2">
                          Belum ada data sensor
                        </h3>
                        <p className="text-gray-500 mb-4">
                          Grafik akan muncul otomatis saat sensor mengirim data ke MQTT broker
                        </p>
                        <div className="text-sm text-gray-400 bg-gray-50 p-3 rounded-lg">
                          <p className="font-mono">Topic: sensors/[nama-sensor]/data</p>
                          <p className="font-mono mt-1">Format: {"{\"value\": 25.6, \"ts\": 1690000000000}"}</p>
                        </div>
                      </div>
                    </motion.div>
                  ) : (
                    <div className={
                      viewMode === 'grid' 
                        ? 'grid grid-cols-1 xl:grid-cols-2 gap-6'
                        : 'space-y-6'
                    }>
                      {sensorArray.map((sensor) => (
                        <motion.div
                          key={sensor.id}
                          layout
                          className={
                            expandedChart === sensor.name && viewMode === 'grid'
                              ? 'col-span-full'
                              : ''
                          }
                        >
                          <SensorChart
                            sensor={sensor}
                            isExpanded={expandedChart === sensor.name}
                            onExpand={() => handleChartExpand(sensor.name)}
                            onExport={() => console.log('Export chart:', sensor.name)}
                            onDelete={() => handleSensorDelete(sensor.name)}
                          />
                        </motion.div>
                      ))}
                    </div>
                  )}
                </AnimatePresence>
              </motion.div>
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="h-full"
            >
              <AdvancedChart
                sensors={sensorArray}
                title="Multi-Sensor Analytics"
                chartType="comparison"
                showStats={true}
              />
            </motion.div>
          </TabsContent>

          {/* Alerts Tab */}
          <TabsContent value="alerts" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="h-full"
            >
              <AlertPanel />
            </motion.div>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col items-center justify-center h-96 text-center"
            >
              <div className="p-8 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/20 max-w-md">
                <FileText className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">
                  Reporting System
                </h3>
                <p className="text-gray-500 mb-4">
                  Generate comprehensive reports in PDF, Excel, or CSV format
                </p>
                <Badge variant="secondary">Coming Soon</Badge>
              </div>
            </motion.div>
          </TabsContent>

          {/* Admin Tab */}
          <TabsContent value="admin" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              <Card className="bg-white/50 backdrop-blur-sm border-white/20">
                <CardContent className="p-6 text-center">
                  <Users className="w-12 h-12 mx-auto mb-4 text-blue-500" />
                  <h3 className="text-lg font-semibold mb-2">User Management</h3>
                  <p className="text-gray-600 mb-4">Manage users and permissions</p>
                  <Button variant="outline" size="sm">Manage Users</Button>
                </CardContent>
              </Card>

              <Card className="bg-white/50 backdrop-blur-sm border-white/20">
                <CardContent className="p-6 text-center">
                  <Globe className="w-12 h-12 mx-auto mb-4 text-green-500" />
                  <h3 className="text-lg font-semibold mb-2">Webhooks</h3>
                  <p className="text-gray-600 mb-4">Configure external integrations</p>
                  <Button variant="outline" size="sm">Configure</Button>
                </CardContent>
              </Card>

              <Card className="bg-white/50 backdrop-blur-sm border-white/20">
                <CardContent className="p-6 text-center">
                  <Database className="w-12 h-12 mx-auto mb-4 text-purple-500" />
                  <h3 className="text-lg font-semibold mb-2">Backup & Restore</h3>
                  <p className="text-gray-600 mb-4">System backup and recovery</p>
                  <Button variant="outline" size="sm">Manage</Button>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}