import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { SessionProviderWrapper } from "@/components/providers/session-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Kalimaya Sensor Dashboard - Enterprise Sensor Monitoring",
  description: "Real-time sensor monitoring dashboard with advanced analytics, alerts, and reporting",
  keywords: ["IoT", "Sensor Monitoring", "Dashboard", "Analytics", "Alerts", "Kalimaya"],
  authors: [{ name: "Kalimaya Dashboard Team" }],
  icons: {
    icon: "/icon-192x192.png",
  },
  openGraph: {
    title: "Kalimaya Sensor Dashboard",
    description: "Enterprise-grade real-time sensor monitoring platform",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Kalimaya Sensor Dashboard",
    description: "Enterprise-grade real-time sensor monitoring platform",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#3b82f6" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="MQTT Dashboard" />
        <link rel="apple-touch-icon" href="/icon-192x192.png" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <SessionProviderWrapper>
          {children}
          <Toaster />
        </SessionProviderWrapper>
      </body>
    </html>
  );
}
