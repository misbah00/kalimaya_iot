import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';

// GET /api/alerts - Get alerts
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const severity = searchParams.get('severity');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: any = {};
    if (status) where.status = status;
    if (severity) where.severity = severity.toUpperCase();

    const alerts = await prisma.alert.findMany({
      where,
      include: {
        rule: {
          include: {
            sensor: { select: { name: true, color: true } }
          }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: limit
    });

    return NextResponse.json(alerts);
  } catch (error) {
    console.error('Error fetching alerts:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/alerts/rules - Create alert rule
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const data = await request.json();
    const { name, sensorId, condition, threshold, tolerance, severity, cooldownMinutes, notificationChannels } = data;

    const alertRule = await prisma.alertRule.create({
      data: {
        name,
        sensorId,
        userId: session.user.id,
        condition,
        threshold: parseFloat(threshold),
        tolerance: tolerance ? parseFloat(tolerance) : null,
        severity,
        cooldownMinutes: cooldownMinutes || 5,
        notificationChannels
      }
    });

    return NextResponse.json(alertRule, { status: 201 });
  } catch (error) {
    console.error('Error creating alert rule:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}