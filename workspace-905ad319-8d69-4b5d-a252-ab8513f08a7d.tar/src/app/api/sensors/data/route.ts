import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';

// POST /api/sensors/data - Store sensor data
export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const { sensorName, value, timestamp, quality, metadata } = data;

    // Find sensor by name
    const sensor = await prisma.sensor.findUnique({
      where: { name: sensorName }
    });

    if (!sensor) {
      // Auto-create sensor if not exists
      const defaultBroker = await prisma.mqttBroker.findFirst({
        where: { isActive: true }
      });

      if (!defaultBroker) {
        return NextResponse.json({ error: 'No active broker found' }, { status: 400 });
      }

      const newSensor = await prisma.sensor.create({
        data: {
          name: sensorName,
          topic: `sensors/${sensorName}/data`,
          brokerId: defaultBroker.id
        }
      });

      // Store data point
      const dataPoint = await prisma.sensorData.create({
        data: {
          sensorId: newSensor.id,
          value: parseFloat(value),
          timestamp: new Date(timestamp || Date.now()),
          quality: quality || 100,
          metadata
        }
      });

      return NextResponse.json({ sensor: newSensor, dataPoint }, { status: 201 });
    }

    // Store data point
    const dataPoint = await prisma.sensorData.create({
      data: {
        sensorId: sensor.id,
        value: parseFloat(value),
        timestamp: new Date(timestamp || Date.now()),
        quality: quality || 100,
        metadata
      }
    });

    // Check alert rules
    await checkAlertRules(sensor, parseFloat(value));

    return NextResponse.json({ sensor, dataPoint }, { status: 201 });
  } catch (error) {
    console.error('Error storing sensor data:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// GET /api/sensors/data - Get sensor data with filters
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const sensorId = searchParams.get('sensorId');
    const limit = parseInt(searchParams.get('limit') || '100');
    const offset = parseInt(searchParams.get('offset') || '0');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');

    const where: any = {};
    if (sensorId) where.sensorId = sensorId;
    if (startDate || endDate) {
      where.timestamp = {};
      if (startDate) where.timestamp.gte = new Date(startDate);
      if (endDate) where.timestamp.lte = new Date(endDate);
    }

    const dataPoints = await prisma.sensorData.findMany({
      where,
      orderBy: { timestamp: 'desc' },
      take: limit,
      skip: offset,
      include: {
        sensor: {
          select: { name: true, color: true, unit: true }
        }
      }
    });

    return NextResponse.json(dataPoints);
  } catch (error) {
    console.error('Error fetching sensor data:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// Check alert rules for sensor data
async function checkAlertRules(sensor: any, value: number) {
  const alertRules = await prisma.alertRule.findMany({
    where: {
      sensorId: sensor.id,
      isActive: true
    },
    include: { user: true }
  });

  for (const rule of alertRules) {
    const shouldAlert = evaluateAlertCondition(rule.condition, value, rule.threshold, rule.tolerance);
    
    if (shouldAlert) {
      // Check cooldown
      const recentAlert = await prisma.alert.findFirst({
        where: {
          ruleId: rule.id,
          createdAt: {
            gte: new Date(Date.now() - rule.cooldownMinutes * 60 * 1000)
          }
        }
      });

      if (!recentAlert) {
        // Create alert
        await prisma.alert.create({
          data: {
            ruleId: rule.id,
            sensorId: sensor.id,
            value,
            threshold: rule.threshold,
            severity: rule.severity,
            message: `${rule.name}: ${sensor.name} value ${value} ${rule.condition} ${rule.threshold}`
          }
        });

        // Create notification
        await prisma.notification.create({
          data: {
            userId: rule.userId,
            type: 'ALERT',
            title: 'Sensor Alert',
            message: `${rule.name}: ${sensor.name} value ${value} ${rule.condition} ${rule.threshold}`,
            data: {
              sensorName: sensor.name,
              value,
              threshold: rule.threshold,
              severity: rule.severity
            }
          }
        });
      }
    }
  }
}

function evaluateAlertCondition(condition: string, value: number, threshold: number, tolerance?: number): boolean {
  const tol = tolerance || 0;
  
  switch (condition) {
    case 'GREATER_THAN':
      return value > threshold;
    case 'LESS_THAN':
      return value < threshold;
    case 'EQUALS':
      return Math.abs(value - threshold) <= tol;
    case 'NOT_EQUALS':
      return Math.abs(value - threshold) > tol;
    case 'OUTSIDE_RANGE':
      return value < (threshold - tol) || value > (threshold + tol);
    case 'INSIDE_RANGE':
      return value >= (threshold - tol) && value <= (threshold + tol);
    default:
      return false;
  }
}