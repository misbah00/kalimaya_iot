import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';

// GET /api/sensors - Get all sensors
export async function GET() {
  try {
    const session = await getServerSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const sensors = await prisma.sensor.findMany({
      include: {
        broker: true,
        dataPoints: {
          orderBy: { timestamp: 'desc' },
          take: 50
        },
        _count: {
          select: { dataPoints: true }
        }
      }
    });

    return NextResponse.json(sensors);
  } catch (error) {
    console.error('Error fetching sensors:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/sensors - Create new sensor
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const data = await request.json();
    const { name, topic, brokerId, unit, description, color } = data;

    const sensor = await prisma.sensor.create({
      data: {
        name,
        topic,
        brokerId,
        unit,
        description,
        color
      }
    });

    return NextResponse.json(sensor, { status: 201 });
  } catch (error) {
    console.error('Error creating sensor:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}