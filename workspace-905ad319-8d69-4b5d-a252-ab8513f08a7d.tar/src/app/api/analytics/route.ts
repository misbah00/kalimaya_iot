import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';

// GET /api/analytics - Get analytics data
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const sensorId = searchParams.get('sensorId');
    const interval = searchParams.get('interval') || 'hourly';
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');

    // Generate aggregations if needed
    await generateAggregations(sensorId, interval, startDate, endDate);

    // Get aggregated data
    const where: any = {};
    if (sensorId) where.sensorId = sensorId;
    if (startDate || endDate) {
      where.timestamp = {};
      if (startDate) where.timestamp.gte = new Date(startDate);
      if (endDate) where.timestamp.lte = new Date(endDate);
    }

    const aggregations = await prisma.dataAggregation.findMany({
      where,
      include: {
        sensor: {
          select: { name: true, color: true, unit: true }
        }
      },
      orderBy: { timestamp: 'asc' }
    });

    // Get sensor statistics
    const sensorStats = await prisma.sensorData.groupBy({
      by: ['sensorId'],
      where: startDate || endDate ? {
        timestamp: {
          gte: startDate ? new Date(startDate) : undefined,
          lte: endDate ? new Date(endDate) : undefined
        }
      } : undefined,
      _min: { value: true },
      _max: { value: true },
      _avg: { value: true },
      _count: { value: true }
    });

    // Get sensor details
    const sensors = await prisma.sensor.findMany({
      where: sensorId ? { id: sensorId } : undefined,
      select: { id: true, name: true, color: true, unit: true }
    });

    // Combine stats with sensor details
    const statsWithDetails = sensorStats.map(stat => {
      const sensor = sensors.find(s => s.id === stat.sensorId);
      return {
        sensorId: stat.sensorId,
        sensorName: sensor?.name || 'Unknown',
        color: sensor?.color || '#3b82f6',
        unit: sensor?.unit || '',
        min: stat._min.value,
        max: stat._max.value,
        avg: stat._avg.value,
        count: stat._count.value
      };
    });

    return NextResponse.json({
      aggregations,
      stats: statsWithDetails,
      summary: {
        totalSensors: sensors.length,
        totalDataPoints: statsWithDetails.reduce((acc, stat) => acc + stat.count, 0),
        interval
      }
    });
  } catch (error) {
    console.error('Error fetching analytics:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// Generate data aggregations
async function generateAggregations(sensorId?: string, interval?: string, startDate?: string, endDate?: string) {
  const where: any = {};
  if (sensorId) where.sensorId = sensorId;
  if (startDate || endDate) {
    where.timestamp = {};
    if (startDate) where.timestamp.gte = new Date(startDate);
    if (endDate) where.timestamp.lte = new Date(endDate);
  }

  // Get raw data
  const rawData = await prisma.sensorData.findMany({
    where,
    orderBy: { timestamp: 'asc' }
  });

  // Group by interval
  const grouped = groupDataByInterval(rawData, interval || 'hourly');

  // Upsert aggregations
  for (const [key, group] of Object.entries(grouped)) {
    const [sensorIdKey, timestampKey] = key.split('|');
    const values = group.map(g => g.value);
    
    await prisma.dataAggregation.upsert({
      where: {
        sensorId_interval_timestamp: {
          sensorId: sensorIdKey,
          interval: interval || 'hourly',
          timestamp: new Date(timestampKey)
        }
      },
      update: {
        min: Math.min(...values),
        max: Math.max(...values),
        avg: values.reduce((a, b) => a + b, 0) / values.length,
        sum: values.reduce((a, b) => a + b, 0),
        count: values.length,
        variance: calculateVariance(values)
      },
      create: {
        sensorId: sensorIdKey,
        interval: interval || 'hourly',
        timestamp: new Date(timestampKey),
        min: Math.min(...values),
        max: Math.max(...values),
        avg: values.reduce((a, b) => a + b, 0) / values.length,
        sum: values.reduce((a, b) => a + b, 0),
        count: values.length,
        variance: calculateVariance(values)
      }
    });
  }
}

function groupDataByInterval(data: any[], interval: string) {
  const grouped: any = {};
  
  data.forEach(item => {
    const date = new Date(item.timestamp);
    let key: string;
    
    switch (interval) {
      case 'hourly':
        key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:00:00`;
        break;
      case 'daily':
        key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} 00:00:00`;
        break;
      case 'weekly':
        const weekStart = new Date(date);
        weekStart.setDate(date.getDate() - date.getDay());
        key = `${weekStart.getFullYear()}-${String(weekStart.getMonth() + 1).padStart(2, '0')}-${String(weekStart.getDate()).padStart(2, '0')} 00:00:00`;
        break;
      case 'monthly':
        key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-01 00:00:00`;
        break;
      default:
        key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:00:00`;
    }
    
    const groupKey = `${item.sensorId}|${key}`;
    if (!grouped[groupKey]) {
      grouped[groupKey] = [];
    }
    grouped[groupKey].push(item);
  });
  
  return grouped;
}

function calculateVariance(values: number[]): number {
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const squaredDiffs = values.map(value => Math.pow(value - mean, 2));
  return squaredDiffs.reduce((a, b) => a + b, 0) / values.length;
}