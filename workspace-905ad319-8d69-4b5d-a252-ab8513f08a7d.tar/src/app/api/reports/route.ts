import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';

// GET /api/reports - Get reports
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const type = searchParams.get('type');

    const where: any = { userId: session.user.id };
    if (status) where.status = status;
    if (type) where.type = type;

    const reports = await prisma.report.findMany({
      where,
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(reports);
  } catch (error) {
    console.error('Error fetching reports:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/reports - Generate new report
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const data = await request.json();
    const { name, type, parameters, format } = data;

    // Create report record
    const report = await prisma.report.create({
      data: {
        name,
        type,
        userId: session.user.id,
        parameters,
        format: format || 'JSON',
        status: 'GENERATING'
      }
    });

    // Generate report asynchronously
    generateReport(report.id, type, parameters, format);

    return NextResponse.json(report, { status: 201 });
  } catch (error) {
    console.error('Error creating report:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

async function generateReport(reportId: string, type: string, parameters: any, format: string) {
  try {
    let data: any;
    let fileName: string;

    switch (type) {
      case 'SENSOR_DATA':
        data = await generateSensorDataReport(parameters);
        fileName = `sensor-data-${Date.now()}`;
        break;
      case 'ALERT_SUMMARY':
        data = await generateAlertSummaryReport(parameters);
        fileName = `alert-summary-${Date.now()}`;
        break;
      case 'ANALYTICS':
        data = await generateAnalyticsReport(parameters);
        fileName = `analytics-${Date.now()}`;
        break;
      default:
        throw new Error('Unknown report type');
    }

    let filePath: string;
    let fileSize: number;

    switch (format) {
      case 'JSON':
        filePath = `/reports/${fileName}.json`;
        const jsonContent = JSON.stringify(data, null, 2);
        fileSize = Buffer.byteLength(jsonContent, 'utf8');
        // In production, save to cloud storage
        break;
      case 'CSV':
        filePath = `/reports/${fileName}.csv`;
        const csvContent = convertToCSV(data);
        fileSize = Buffer.byteLength(csvContent, 'utf8');
        break;
      case 'PDF':
        filePath = `/reports/${fileName}.pdf`;
        const pdfDoc = generatePDF(data);
        fileSize = pdfDoc.output().length;
        break;
      case 'EXCEL':
        filePath = `/reports/${fileName}.xlsx`;
        const excelBuffer = generateExcel(data);
        fileSize = excelBuffer.length;
        break;
      default:
        throw new Error('Unknown format');
    }

    // Update report record
    await prisma.report.update({
      where: { id: reportId },
      data: {
        status: 'COMPLETED',
        filePath,
        fileSize,
        generatedAt: new Date()
      }
    });

  } catch (error) {
    console.error('Error generating report:', error);
    await prisma.report.update({
      where: { id: reportId },
      data: { status: 'FAILED' }
    });
  }
}

async function generateSensorDataReport(parameters: any) {
  const { sensorIds, startDate, endDate } = parameters;
  
  const data = await prisma.sensorData.findMany({
    where: {
      sensorId: { in: sensorIds },
      timestamp: {
        gte: new Date(startDate),
        lte: new Date(endDate)
      }
    },
    include: {
      sensor: {
        select: { name: true, unit: true, color: true }
      }
    },
    orderBy: { timestamp: 'asc' }
  });

  return {
    metadata: {
      generatedAt: new Date(),
      sensorCount: sensorIds.length,
      dataPoints: data.length,
      dateRange: { startDate, endDate }
    },
    data
  };
}

async function generateAlertSummaryReport(parameters: any) {
  const { startDate, endDate, severity } = parameters;
  
  const where: any = {};
  if (startDate || endDate) {
    where.createdAt = {};
    if (startDate) where.createdAt.gte = new Date(startDate);
    if (endDate) where.createdAt.lte = new Date(endDate);
  }
  if (severity) where.severity = severity;

  const alerts = await prisma.alert.findMany({
    where,
    include: {
      rule: {
        include: {
          sensor: { select: { name: true } }
        }
      }
    },
    orderBy: { createdAt: 'desc' }
  });

  const summary = {
    total: alerts.length,
    bySeverity: alerts.reduce((acc, alert) => {
      acc[alert.severity] = (acc[alert.severity] || 0) + 1;
      return acc;
    }, {} as Record<string, number>),
    byStatus: alerts.reduce((acc, alert) => {
      acc[alert.status] = (acc[alert.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>)
  };

  return {
    metadata: {
      generatedAt: new Date(),
      dateRange: { startDate, endDate }
    },
    summary,
    alerts
  };
}

async function generateAnalyticsReport(parameters: any) {
  const { sensorIds, interval, startDate, endDate } = parameters;
  
  const response = await fetch(`${process.env.NEXTAUTH_URL}/api/analytics?${new URLSearchParams({
    sensorId: sensorIds.join(','),
    interval,
    startDate,
    endDate
  })}`);
  
  return await response.json();
}

function convertToCSV(data: any): string {
  if (!data.data || !Array.isArray(data.data)) return '';
  
  const headers = Object.keys(data.data[0]);
  const csvRows = [
    headers.join(','),
    ...data.data.map((row: any) => 
      headers.map(header => `"${row[header]}"`).join(',')
    )
  ];
  
  return csvRows.join('\n');
}

function generatePDF(data: any): jsPDF {
  const doc = new jsPDF();
  doc.text('MQTT Dashboard Report', 20, 20);
  doc.text(`Generated: ${new Date().toLocaleString()}`, 20, 30);
  
  let yPosition = 50;
  doc.text('Data:', 20, yPosition);
  yPosition += 10;
  
  if (data.data && Array.isArray(data.data)) {
    data.data.slice(0, 20).forEach((item: any, index: number) => {
      doc.text(`${index + 1}. ${JSON.stringify(item)}`, 20, yPosition);
      yPosition += 10;
      
      if (yPosition > 270) {
        doc.addPage();
        yPosition = 20;
      }
    });
  }
  
  return doc;
}

function generateExcel(data: any): Buffer {
  const wb = XLSX.utils.book_new();
  
  if (data.data && Array.isArray(data.data)) {
    const ws = XLSX.utils.json_to_sheet(data.data);
    XLSX.utils.book_append_sheet(wb, ws, 'Data');
  }
  
  return XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
}