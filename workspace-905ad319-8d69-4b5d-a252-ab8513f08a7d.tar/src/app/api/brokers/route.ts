import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';

// GET /api/brokers - Get all MQTT brokers
export async function GET() {
  try {
    const session = await getServerSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const brokers = await prisma.mqttBroker.findMany({
      include: {
        _count: {
          select: { sensors: true }
        }
      },
      orderBy: { priority: 'asc' }
    });

    return NextResponse.json(brokers);
  } catch (error) {
    console.error('Error fetching brokers:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/brokers - Create new MQTT broker
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const data = await request.json();
    const { name, url, port, username, password, clientId, priority } = data;

    const broker = await prisma.mqttBroker.create({
      data: {
        name,
        url,
        port,
        username,
        password, // In production, encrypt this
        clientId,
        priority: priority || 1
      }
    });

    return NextResponse.json(broker, { status: 201 });
  } catch (error) {
    console.error('Error creating broker:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}