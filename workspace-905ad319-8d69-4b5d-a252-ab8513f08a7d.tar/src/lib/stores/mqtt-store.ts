import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';

// Types untuk sensor data
export interface SensorData {
  value: number;
  timestamp: number;
  formattedTime: string;
}

export interface Sensor {
  id: string;
  name: string;
  data: SensorData[];
  lastValue: number;
  lastUpdate: number;
  color: string;
  unit?: string;
  min?: number;
  max?: number;
  isActive: boolean;
}

export interface MQTTConfig {
  brokerUrl: string;
  clientId: string;
  topic: string;
  keepalive: number;
  clean: boolean;
  reconnectPeriod: number;
  connectTimeout: number;
}

export interface ChartConfig {
  maxDataPoints: number;
  updateInterval: number;
  animationDuration: number;
  showGrid: boolean;
  showLegend: boolean;
  chartType: 'line' | 'bar' | 'area';
}

interface MQTTStore {
  // State
  sensors: Map<string, Sensor>;
  connectionStatus: 'connected' | 'disconnected' | 'connecting' | 'error';
  mqttConfig: MQTTConfig;
  chartConfig: ChartConfig;
  selectedSensor: string | null;
  isSettingsOpen: boolean;
  notifications: Array<{
    id: string;
    type: 'success' | 'error' | 'info' | 'warning';
    message: string;
    timestamp: number;
  }>;
  
  // Actions
  addSensor: (sensorName: string, data: SensorData) => void;
  updateSensor: (sensorName: string, data: SensorData) => void;
  removeSensor: (sensorName: string) => void;
  setConnectionStatus: (status: MQTTStore['connectionStatus']) => void;
  updateMQTTConfig: (config: Partial<MQTTConfig>) => void;
  updateChartConfig: (config: Partial<ChartConfig>) => void;
  setSelectedSensor: (sensorName: string | null) => void;
  toggleSettings: () => void;
  addNotification: (type: MQTTStore['notifications'][0]['type'], message: string) => void;
  removeNotification: (id: string) => void;
  clearAllData: () => void;
  exportData: () => string;
  getSensorStats: (sensorName: string) => {
    min: number;
    max: number;
    avg: number;
    count: number;
  } | null;
}

// Default configurations
const defaultMQTTConfig: MQTTConfig = {
  brokerUrl: 'wss://broker.emqx.io:8084/mqtt',
  clientId: `mqtt_dashboard_${Math.random().toString(16).substr(2, 8)}`,
  topic: 'sensors/+/data',
  keepalive: 60,
  clean: true,
  reconnectPeriod: 1000,
  connectTimeout: 30000,
};

const defaultChartConfig: ChartConfig = {
  maxDataPoints: 50,
  updateInterval: 1000,
  animationDuration: 300,
  showGrid: true,
  showLegend: false,
  chartType: 'line',
};

// Color palette for sensors
const sensorColors = [
  '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', 
  '#ec4899', '#06b6d4', '#84cc16', '#f97316', '#14b8a6'
];

let colorIndex = 0;

const getSensorColor = () => {
  const color = sensorColors[colorIndex % sensorColors.length];
  colorIndex++;
  return color;
};

export const useMQTTStore = create<MQTTStore>()(
  subscribeWithSelector((set, get) => ({
    // Initial state
    sensors: new Map(),
    connectionStatus: 'disconnected',
    mqttConfig: defaultMQTTConfig,
    chartConfig: defaultChartConfig,
    selectedSensor: null,
    isSettingsOpen: false,
    notifications: [],

    // Actions
    addSensor: (sensorName: string, data: SensorData) => {
      set((state) => {
        const newSensors = new Map(state.sensors);
        const newSensor: Sensor = {
          id: sensorName,
          name: sensorName,
          data: [data],
          lastValue: data.value,
          lastUpdate: data.timestamp,
          color: getSensorColor(),
          isActive: true,
        };
        newSensors.set(sensorName, newSensor);
        
        // Add notification
        get().addNotification('success', `Sensor "${sensorName}" terdeteksi`);
        
        return { sensors: newSensors };
      });
    },

    updateSensor: (sensorName: string, data: SensorData) => {
      set((state) => {
        const newSensors = new Map(state.sensors);
        const sensor = newSensors.get(sensorName);
        
        if (!sensor) return state;
        
        // Add new data
        const updatedData = [...sensor.data, data];
        
        // Limit data points
        const maxPoints = state.chartConfig.maxDataPoints;
        if (updatedData.length > maxPoints) {
          updatedData.splice(0, updatedData.length - maxPoints);
        }
        
        const updatedSensor = {
          ...sensor,
          data: updatedData,
          lastValue: data.value,
          lastUpdate: data.timestamp,
        };
        
        newSensors.set(sensorName, updatedSensor);
        return { sensors: newSensors };
      });
    },

    removeSensor: (sensorName: string) => {
      set((state) => {
        const newSensors = new Map(state.sensors);
        newSensors.delete(sensorName);
        get().addNotification('info', `Sensor "${sensorName}" dihapus`);
        return { sensors: newSensors };
      });
    },

    setConnectionStatus: (status) => {
      set({ connectionStatus: status });
      
      const messages = {
        connected: 'Berhasil terhubung ke MQTT broker',
        disconnected: 'Terputus dari MQTT broker',
        connecting: 'Menghubungkan ke MQTT broker...',
        error: 'Error koneksi MQTT',
      };
      
      if (status !== 'connecting') {
        get().addNotification(
          status === 'connected' ? 'success' : 'error',
          messages[status]
        );
      }
    },

    updateMQTTConfig: (config) => {
      set((state) => ({
        mqttConfig: { ...state.mqttConfig, ...config }
      }));
    },

    updateChartConfig: (config) => {
      set((state) => ({
        chartConfig: { ...state.chartConfig, ...config }
      }));
    },

    setSelectedSensor: (sensorName) => {
      set({ selectedSensor: sensorName });
    },

    toggleSettings: () => {
      set((state) => ({ isSettingsOpen: !state.isSettingsOpen }));
    },

    addNotification: (type, message) => {
      const id = Date.now().toString();
      set((state) => ({
        notifications: [
          ...state.notifications,
          { id, type, message, timestamp: Date.now() }
        ]
      }));
      
      // Auto remove after 5 seconds
      setTimeout(() => {
        get().removeNotification(id);
      }, 5000);
    },

    removeNotification: (id) => {
      set((state) => ({
        notifications: state.notifications.filter(n => n.id !== id)
      }));
    },

    clearAllData: () => {
      set({
        sensors: new Map(),
        selectedSensor: null,
        notifications: []
      });
      get().addNotification('info', 'Semua data telah dibersihkan');
    },

    exportData: () => {
      const { sensors } = get();
      const exportData = {
        timestamp: Date.now(),
        sensors: Array.from(sensors.entries()).map(([name, sensor]) => ({
          name,
          ...sensor,
          data: sensor.data.map(d => ({
            value: d.value,
            timestamp: d.timestamp,
            formattedTime: d.formattedTime
          }))
        }))
      };
      
      return JSON.stringify(exportData, null, 2);
    },

    getSensorStats: (sensorName: string) => {
      const sensor = get().sensors.get(sensorName);
      if (!sensor || sensor.data.length === 0) return null;
      
      const values = sensor.data.map(d => d.value);
      const min = Math.min(...values);
      const max = Math.max(...values);
      const avg = values.reduce((a, b) => a + b, 0) / values.length;
      
      return { min, max, avg, count: values.length };
    },
  }))
);

// Subscribe to connection status changes for logging
useMQTTStore.subscribe(
  (state) => state.connectionStatus,
  (status) => {
    console.log('MQTT Connection Status:', status);
  }
);