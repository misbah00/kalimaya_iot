'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useMQTTStore } from '@/lib/stores/mqtt-store';
import { 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  X,
  Bell,
  BellOff,
  Filter,
  RefreshCw
} from 'lucide-react';
import { format } from 'date-fns';

interface Alert {
  id: string;
  ruleId: string;
  sensorId: string;
  value: number;
  threshold: number;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  message: string;
  status: 'ACTIVE' | 'ACKNOWLEDGED' | 'RESOLVED' | 'SUPPRESSED';
  createdAt: string;
  resolvedAt?: string;
  rule: {
    sensor: {
      name: string;
      color: string;
    };
  };
}

export const AlertPanel = () => {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [filter, setFilter] = useState<'all' | 'active' | 'acknowledged' | 'resolved'>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(false);
  const { addNotification } = useMQTTStore();

  // Fetch alerts
  const fetchAlerts = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/alerts');
      if (response.ok) {
        const data = await response.json();
        setAlerts(data);
      }
    } catch (error) {
      console.error('Error fetching alerts:', error);
      addNotification('error', 'Failed to fetch alerts');
    } finally {
      setIsLoading(false);
    }
  };

  // Acknowledge alert
  const acknowledgeAlert = async (alertId: string) => {
    try {
      const response = await fetch(`/api/alerts/${alertId}/acknowledge`, {
        method: 'POST'
      });
      
      if (response.ok) {
        setAlerts(prev => 
          prev.map(alert => 
            alert.id === alertId 
              ? { ...alert, status: 'ACKNOWLEDGED' }
              : alert
          )
        );
        addNotification('success', 'Alert acknowledged');
      }
    } catch (error) {
      console.error('Error acknowledging alert:', error);
      addNotification('error', 'Failed to acknowledge alert');
    }
  };

  // Resolve alert
  const resolveAlert = async (alertId: string) => {
    try {
      const response = await fetch(`/api/alerts/${alertId}/resolve`, {
        method: 'POST'
      });
      
      if (response.ok) {
        setAlerts(prev => 
          prev.map(alert => 
            alert.id === alertId 
              ? { ...alert, status: 'RESOLVED', resolvedAt: new Date().toISOString() }
              : alert
          )
        );
        addNotification('success', 'Alert resolved');
      }
    } catch (error) {
      console.error('Error resolving alert:', error);
      addNotification('error', 'Failed to resolve alert');
    }
  };

  // Filter alerts
  const filteredAlerts = alerts.filter(alert => {
    if (filter !== 'all' && alert.status.toLowerCase() !== filter) return false;
    if (severityFilter !== 'all' && alert.severity !== severityFilter) return false;
    return true;
  });

  // Get severity color
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'CRITICAL': return 'bg-red-500';
      case 'HIGH': return 'bg-orange-500';
      case 'MEDIUM': return 'bg-yellow-500';
      case 'LOW': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ACTIVE': return 'bg-red-100 text-red-800 border-red-200';
      case 'ACKNOWLEDGED': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'RESOLVED': return 'bg-green-100 text-green-800 border-green-200';
      case 'SUPPRESSED': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  // Auto-refresh alerts
  useEffect(() => {
    fetchAlerts();
    const interval = setInterval(fetchAlerts, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const activeCount = alerts.filter(a => a.status === 'ACTIVE').length;

  return (
    <Card className="h-full shadow-lg">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-500" />
            Alert System
            {activeCount > 0 && (
              <Badge variant="destructive" className="ml-2">
                {activeCount} Active
              </Badge>
            )}
          </CardTitle>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={fetchAlerts}
            disabled={isLoading}
            className="h-8 w-8 p-0"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
        
        {/* Filters */}
        <div className="flex gap-2 flex-wrap">
          <Select value={filter} onValueChange={(value: any) => setFilter(value)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="acknowledged">Acknowledged</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={severityFilter} onValueChange={setSeverityFilter}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Severity</SelectItem>
              <SelectItem value="CRITICAL">Critical</SelectItem>
              <SelectItem value="HIGH">High</SelectItem>
              <SelectItem value="MEDIUM">Medium</SelectItem>
              <SelectItem value="LOW">Low</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]">
          <AnimatePresence mode="popLayout">
            {filteredAlerts.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="p-6 text-center text-muted-foreground"
              >
                <CheckCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p className="font-medium">No alerts found</p>
                <p className="text-sm mt-1">
                  {filter === 'all' ? 'System is running smoothly' : `No ${filter} alerts`}
                </p>
              </motion.div>
            ) : (
              <div className="p-4 space-y-2">
                {filteredAlerts.map((alert) => (
                  <motion.div
                    key={alert.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.2 }}
                    whileHover={{ scale: 1.01 }}
                  >
                    <Card className={`border-l-4 ${getStatusColor(alert.status)}`}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-2">
                              <div className={`w-2 h-2 rounded-full ${getSeverityColor(alert.severity)}`} />
                              <span className="font-semibold text-sm">
                                {alert.rule.sensor.name}
                              </span>
                              <Badge variant="outline" className="text-xs">
                                {alert.severity}
                              </Badge>
                              <Badge variant="secondary" className="text-xs">
                                {alert.status}
                              </Badge>
                            </div>
                            
                            <p className="text-sm text-gray-700 mb-2">
                              {alert.message}
                            </p>
                            
                            <div className="flex items-center gap-4 text-xs text-gray-500">
                              <span>Value: {alert.value}</span>
                              <span>Threshold: {alert.threshold}</span>
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {format(new Date(alert.createdAt), 'HH:mm:ss')}
                              </span>
                            </div>
                          </div>
                          
                          <div className="flex gap-1 ml-2">
                            {alert.status === 'ACTIVE' && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => acknowledgeAlert(alert.id)}
                                className="h-8 w-8 p-0 text-yellow-600 hover:text-yellow-700"
                              >
                                <Bell className="w-4 h-4" />
                              </Button>
                            )}
                            
                            {alert.status === 'ACKNOWLEDGED' && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => resolveAlert(alert.id)}
                                className="h-8 w-8 p-0 text-green-600 hover:text-green-700"
                              >
                                <CheckCircle className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </AnimatePresence>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};