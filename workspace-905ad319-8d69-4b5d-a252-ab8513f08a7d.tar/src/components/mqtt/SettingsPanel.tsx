'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useMQTTStore } from '@/lib/stores/mqtt-store';
import { useMQTT } from '@/hooks/use-mqtt';
import { 
  Settings, 
  Download, 
  Upload, 
  Trash2, 
  Save, 
  RotateCcw,
  Play,
  Square,
  TestTube
} from 'lucide-react';

export const SettingsPanel = () => {
  const [testSensorName, setTestSensorName] = useState('test-sensor');
  const [testValue, setTestValue] = useState(50);
  
  const {
    mqttConfig,
    chartConfig,
    updateMQTTConfig,
    updateChartConfig,
    clearAllData,
    exportData,
    isSettingsOpen,
    toggleSettings
  } = useMQTTStore();
  
  const { 
    connectionStatus, 
    connect, 
    disconnect, 
    reconnect,
    sendTestData,
    startTestStream,
    stopTestStream,
    isConnected 
  } = useMQTT();

  // Handle MQTT config change
  const handleMQTTConfigChange = (field: string, value: any) => {
    updateMQTTConfig({ [field]: value });
  };

  // Handle chart config change
  const handleChartConfigChange = (field: string, value: any) => {
    updateChartConfig({ [field]: value });
  };

  // Export data
  const handleExportData = () => {
    const data = exportData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `mqtt-dashboard-export-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Import data
  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target?.result as string);
          // Import logic would go here
          console.log('Import data:', data);
        } catch (error) {
          console.error('Error importing data:', error);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <AnimatePresence>
      {isSettingsOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={toggleSettings}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="bg-background rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <Card className="h-full">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Pengaturan Dashboard
                </CardTitle>
                <Button variant="ghost" size="sm" onClick={toggleSettings}>
                  ×
                </Button>
              </CardHeader>
              
              <CardContent className="overflow-y-auto">
                <Tabs defaultValue="mqtt" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="mqtt">MQTT</TabsTrigger>
                    <TabsTrigger value="chart">Grafik</TabsTrigger>
                    <TabsTrigger value="test">Testing</TabsTrigger>
                    <TabsTrigger value="data">Data</TabsTrigger>
                  </TabsList>
                  
                  {/* MQTT Settings */}
                  <TabsContent value="mqtt" className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="brokerUrl">Broker URL</Label>
                        <Input
                          id="brokerUrl"
                          value={mqttConfig.brokerUrl}
                          onChange={(e) => handleMQTTConfigChange('brokerUrl', e.target.value)}
                          placeholder="wss://broker.emqx.io:8084/mqtt"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="clientId">Client ID</Label>
                        <Input
                          id="clientId"
                          value={mqttConfig.clientId}
                          onChange={(e) => handleMQTTConfigChange('clientId', e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="topic">Topic</Label>
                        <Input
                          id="topic"
                          value={mqttConfig.topic}
                          onChange={(e) => handleMQTTConfigChange('topic', e.target.value)}
                          placeholder="sensors/+/data"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="keepalive">Keepalive (detik)</Label>
                        <Input
                          id="keepalive"
                          type="number"
                          value={mqttConfig.keepalive}
                          onChange={(e) => handleMQTTConfigChange('keepalive', parseInt(e.target.value))}
                        />
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button
                        onClick={isConnected ? disconnect : connect}
                        variant={isConnected ? "destructive" : "default"}
                        className="flex items-center gap-2"
                      >
                        {isConnected ? (
                          <>
                            <Square className="w-4 h-4" />
                            Disconnect
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4" />
                            Connect
                          </>
                        )}
                      </Button>
                      
                      <Button
                        onClick={reconnect}
                        variant="outline"
                        className="flex items-center gap-2"
                      >
                        <RotateCcw className="w-4 h-4" />
                        Reconnect
                      </Button>
                    </div>
                    
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="text-sm font-medium">Status Koneksi:</p>
                      <p className="text-sm text-muted-foreground capitalize">
                        {connectionStatus}
                      </p>
                    </div>
                  </TabsContent>
                  
                  {/* Chart Settings */}
                  <TabsContent value="chart" className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Tipe Grafik</Label>
                        <Select
                          value={chartConfig.chartType}
                          onValueChange={(value) => handleChartConfigChange('chartType', value)}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="line">Line</SelectItem>
                            <SelectItem value="area">Area</SelectItem>
                            <SelectItem value="bar">Bar</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Maksimum Data Points: {chartConfig.maxDataPoints}</Label>
                        <Slider
                          value={[chartConfig.maxDataPoints]}
                          onValueChange={([value]) => handleChartConfigChange('maxDataPoints', value)}
                          max={100}
                          min={10}
                          step={5}
                          className="w-full"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Animasi Duration (ms): {chartConfig.animationDuration}</Label>
                        <Slider
                          value={[chartConfig.animationDuration]}
                          onValueChange={([value]) => handleChartConfigChange('animationDuration', value)}
                          max={2000}
                          min={0}
                          step={100}
                          className="w-full"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Update Interval (ms): {chartConfig.updateInterval}</Label>
                        <Slider
                          value={[chartConfig.updateInterval]}
                          onValueChange={([value]) => handleChartConfigChange('updateInterval', value)}
                          max={5000}
                          min={100}
                          step={100}
                          className="w-full"
                        />
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="showGrid"
                        checked={chartConfig.showGrid}
                        onCheckedChange={(checked) => handleChartConfigChange('showGrid', checked)}
                      />
                      <Label htmlFor="showGrid">Tampilkan Grid</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="showLegend"
                        checked={chartConfig.showLegend}
                        onCheckedChange={(checked) => handleChartConfigChange('showLegend', checked)}
                      />
                      <Label htmlFor="showLegend">Tampilkan Legend</Label>
                    </div>
                  </TabsContent>
                  
                  {/* Testing */}
                  <TabsContent value="test" className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="testSensorName">Nama Sensor Test</Label>
                        <Input
                          id="testSensorName"
                          value={testSensorName}
                          onChange={(e) => setTestSensorName(e.target.value)}
                          placeholder="test-sensor"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="testValue">Nilai Test: {testValue}</Label>
                        <Slider
                          value={[testValue]}
                          onValueChange={([value]) => setTestValue(value)}
                          max={100}
                          min={0}
                          step={1}
                          className="w-full"
                        />
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button
                        onClick={() => sendTestData(testSensorName, testValue)}
                        disabled={!isConnected}
                        className="flex items-center gap-2"
                      >
                        <TestTube className="w-4 h-4" />
                        Kirim Data Test
                      </Button>
                      
                      <Button
                        onClick={() => startTestStream()}
                        disabled={!isConnected}
                        variant="outline"
                        className="flex items-center gap-2"
                      >
                        <Play className="w-4 h-4" />
                        Start Stream
                      </Button>
                      
                      <Button
                        onClick={stopTestStream}
                        variant="outline"
                        className="flex items-center gap-2"
                      >
                        <Square className="w-4 h-4" />
                        Stop Stream
                      </Button>
                    </div>
                    
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="text-sm font-medium">Info Testing:</p>
                      <p className="text-sm text-muted-foreground">
                        Gunakan fitur testing untuk simulasi data sensor. 
                        Data akan dikirim ke topic sensors/[nama-sensor]/data
                      </p>
                    </div>
                  </TabsContent>
                  
                  {/* Data Management */}
                  <TabsContent value="data" className="space-y-4">
                    <div className="flex gap-2">
                      <Button
                        onClick={handleExportData}
                        variant="outline"
                        className="flex items-center gap-2"
                      >
                        <Download className="w-4 h-4" />
                        Export Data
                      </Button>
                      
                      <Button
                        onClick={() => document.getElementById('import-file')?.click()}
                        variant="outline"
                        className="flex items-center gap-2"
                      >
                        <Upload className="w-4 h-4" />
                        Import Data
                      </Button>
                      
                      <input
                        id="import-file"
                        type="file"
                        accept=".json"
                        onChange={handleImportData}
                        className="hidden"
                      />
                      
                      <Button
                        onClick={clearAllData}
                        variant="destructive"
                        className="flex items-center gap-2"
                      >
                        <Trash2 className="w-4 h-4" />
                        Clear All Data
                      </Button>
                    </div>
                    
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="text-sm font-medium">Info Data:</p>
                      <p className="text-sm text-muted-foreground">
                        Export data akan menghasilkan file JSON dengan semua data sensor. 
                        Import data akan menggantikan data saat ini.
                      </p>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};