'use client';

import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useMQTTStore } from '@/lib/stores/mqtt-store';
import { 
  ChartLine, 
  Settings, 
  Satellite, 
  Activity,
  Circle
} from 'lucide-react';

export const Header = () => {
  const { connectionStatus, sensors, toggleSettings } = useMQTTStore();

  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'text-green-500';
      case 'connecting':
        return 'text-yellow-500';
      case 'error':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };

  const getStatusText = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'Terhubung';
      case 'connecting':
        return 'Menghubungkan...';
      case 'error':
        return 'Error';
      default:
        return 'Terputus';
    }
  };

  const activeSensorCount = Array.from(sensors.values()).filter(s => s.isActive).length;

  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b shadow-sm"
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center gap-2"
            >
              <div className="p-2 bg-primary/10 rounded-lg">
                <ChartLine className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Kalimaya Sensor Dashboard
                </h1>
                <p className="text-sm text-gray-500">
                  Real-time Sensor Monitoring
                </p>
              </div>
            </motion.div>
          </div>

          <div className="flex items-center gap-4">
            {/* Connection Status */}
            <motion.div
              className={`flex items-center gap-2 px-4 py-2 rounded-full border ${getStatusColor()} bg-white/50`}
              whileHover={{ scale: 1.05 }}
            >
              <Circle className={`w-3 h-3 fill-current ${connectionStatus === 'connected' ? 'animate-pulse' : ''}`} />
              <span className="text-sm font-medium">
                {getStatusText()}
              </span>
            </motion.div>

            {/* Active Sensors */}
            <motion.div
              className="flex items-center gap-2 px-4 py-2 rounded-full border border-gray-200 bg-white/50"
              whileHover={{ scale: 1.05 }}
            >
              <Satellite className="w-4 h-4 text-gray-600" />
              <span className="text-sm font-medium text-gray-700">
                {activeSensorCount} Sensor
              </span>
            </motion.div>

            {/* Activity Indicator */}
            {connectionStatus === 'connected' && (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                className="flex items-center gap-2 px-4 py-2 rounded-full border border-green-200 bg-green-50"
              >
                <Activity className="w-4 h-4 text-green-600" />
                <span className="text-sm font-medium text-green-700">
                  Active
                </span>
              </motion.div>
            )}

            {/* Settings Button */}
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                variant="outline"
                size="sm"
                onClick={toggleSettings}
                className="flex items-center gap-2"
              >
                <Settings className="w-4 h-4" />
                Settings
              </Button>
            </motion.div>
          </div>
        </div>
      </div>
    </motion.header>
  );
};