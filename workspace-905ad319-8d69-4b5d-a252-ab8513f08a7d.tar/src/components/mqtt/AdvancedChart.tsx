'use client';

import { useEffect, useRef, memo, useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Line, Bar } from 'react-chartjs-2';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { 
  Maximize2, 
  Download, 
  Settings, 
  TrendingUp, 
  TrendingDown,
  Activity,
  Layers,
  BarChart3,
  LineChart
} from 'lucide-react';
import { Sensor } from '@/lib/stores/mqtt-store';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface AdvancedChartProps {
  sensors: Sensor[];
  title?: string;
  isExpanded?: boolean;
  onExpand?: () => void;
  onExport?: () => void;
  chartType?: 'line' | 'bar' | 'comparison';
  showStats?: boolean;
}

export const AdvancedChart = memo<AdvancedChartProps>(({
  sensors,
  title = 'Multi-Sensor Comparison',
  isExpanded = false,
  onExpand,
  onExport,
  chartType = 'comparison',
  showStats = true
}) => {
  const chartRef = useRef<any>(null);
  const [selectedSensors, setSelectedSensors] = useState<string[]>(sensors.map(s => s.id));
  const [showLegend, setShowLegend] = useState(true);
  const [showGrid, setShowGrid] = useState(true);
  const [chartMode, setChartMode] = useState<'line' | 'bar'>('line');

  // Filter sensors based on selection
  const activeSensors = sensors.filter(s => selectedSensors.includes(s.id));

  // Prepare chart data
  const chartData = {
    labels: activeSensors.length > 0 
      ? activeSensors[0].data.map(d => d.formattedTime)
      : [],
    datasets: activeSensors.map(sensor => ({
      label: sensor.name,
      data: sensor.data.map(d => d.value),
      borderColor: sensor.color,
      backgroundColor: chartMode === 'bar' 
        ? sensor.color 
        : sensor.color + '20',
      borderWidth: 2,
      fill: chartMode === 'line' ? true : false,
      tension: 0.4,
      pointRadius: isExpanded ? 4 : 3,
      pointHoverRadius: 6,
      pointBackgroundColor: sensor.color,
      pointBorderColor: '#fff',
      pointBorderWidth: 2,
      pointStyle: 'circle',
      hidden: !selectedSensors.includes(sensor.id),
    }))
  };

  // Chart options
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: {
      mode: 'index' as const,
      intersect: false,
    },
    plugins: {
      legend: {
        display: showLegend,
        position: 'top' as const,
        labels: {
          color: '#666',
          font: {
            weight: 'bold',
          },
          usePointStyle: true,
          padding: 20,
        },
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: '#333',
        borderWidth: 1,
        displayColors: true,
        callbacks: {
          label: (context: any) => {
            const label = context.dataset.label || '';
            const value = context.parsed.y.toFixed(2);
            return `${label}: ${value}`;
          },
        },
      },
    },
    scales: {
      x: {
        display: true,
        grid: {
          display: showGrid,
          color: 'rgba(0, 0, 0, 0.05)',
        },
        ticks: {
          maxTicksLimit: isExpanded ? 12 : 8,
          color: '#666',
        },
      },
      y: {
        display: true,
        grid: {
          display: showGrid,
          color: 'rgba(0, 0, 0, 0.05)',
        },
        ticks: {
          color: '#666',
        },
        beginAtZero: false,
      },
    },
  };

  // Calculate statistics
  const calculateStats = () => {
    const stats = activeSensors.map(sensor => {
      const values = sensor.data.map(d => d.value);
      if (values.length === 0) return null;
      
      const min = Math.min(...values);
      const max = Math.max(...values);
      const avg = values.reduce((a, b) => a + b, 0) / values.length;
      const latest = sensor.lastValue;
      
      return {
        sensorName: sensor.name,
        color: sensor.color,
        min,
        max,
        avg,
        latest,
        trend: values.length > 1 ? 
          (values[values.length - 1] - values[values.length - 2]) : 0
      };
    }).filter(Boolean);
    
    return stats;
  };

  const stats = calculateStats();

  // Toggle sensor visibility
  const toggleSensor = (sensorId: string) => {
    setSelectedSensors(prev => 
      prev.includes(sensorId) 
        ? prev.filter(id => id !== sensorId)
        : [...prev, sensorId]
    );
  };

  // Export chart as image
  const exportChart = () => {
    if (chartRef.current) {
      const url = chartRef.current.toBase64Image();
      const link = document.createElement('a');
      link.download = `advanced-chart-${Date.now()}.png`;
      link.href = url;
      link.click();
    }
    onExport?.();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      whileHover={{ y: -2 }}
      className="h-full"
    >
      <Card className="h-full shadow-lg hover:shadow-xl transition-shadow duration-300">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-primary" />
              <CardTitle className="text-lg font-semibold">
                {title}
              </CardTitle>
              <Badge variant="secondary" className="text-xs">
                {activeSensors.length} sensors
              </Badge>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setChartMode(chartMode === 'line' ? 'bar' : 'line')}
                className="h-8 w-8 p-0"
              >
                {chartMode === 'line' ? (
                  <BarChart3 className="w-4 h-4" />
                ) : (
                  <LineChart className="w-4 h-4" />
                )}
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={onExpand}
                className="h-8 w-8 p-0"
              >
                <Maximize2 className="w-4 h-4" />
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={exportChart}
                className="h-8 w-8 p-0"
              >
                <Download className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          {/* Sensor Toggles */}
          <div className="flex flex-wrap gap-2 mt-3">
            {sensors.map(sensor => (
              <div
                key={sensor.id}
                className="flex items-center gap-2 px-2 py-1 rounded-md border border-gray-200"
                style={{ borderColor: selectedSensors.includes(sensor.id) ? sensor.color : undefined }}
              >
                <Switch
                  checked={selectedSensors.includes(sensor.id)}
                  onCheckedChange={() => toggleSensor(sensor.id)}
                  size="sm"
                />
                <Label 
                  className="text-sm font-medium cursor-pointer"
                  style={{ color: selectedSensors.includes(sensor.id) ? sensor.color : undefined }}
                >
                  {sensor.name}
                </Label>
              </div>
            ))}
          </div>
          
          {/* Chart Controls */}
          <div className="flex items-center gap-4 mt-3 text-sm">
            <div className="flex items-center gap-2">
              <Switch
                checked={showLegend}
                onCheckedChange={setShowLegend}
                size="sm"
              />
              <Label>Legend</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch
                checked={showGrid}
                onCheckedChange={setShowGrid}
                size="sm"
              />
              <Label>Grid</Label>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="pt-0">
          {/* Statistics */}
          {showStats && stats && stats.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
              {stats.map((stat: any, index) => (
                <div
                  key={stat.sensorName}
                  className="p-3 rounded-lg border"
                  style={{ borderColor: stat.color + '30' }}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span 
                      className="text-sm font-medium"
                      style={{ color: stat.color }}
                    >
                      {stat.sensorName}
                    </span>
                    {stat.trend !== 0 && (
                      stat.trend > 0 ? (
                        <TrendingUp className="w-3 h-3 text-green-500" />
                      ) : (
                        <TrendingDown className="w-3 h-3 text-red-500" />
                      )
                    )}
                  </div>
                  <div className="text-xs text-gray-600 space-y-1">
                    <div>Min: {stat.min.toFixed(2)}</div>
                    <div>Max: {stat.max.toFixed(2)}</div>
                    <div>Avg: {stat.avg.toFixed(2)}</div>
                    <div className="font-semibold">Current: {stat.latest.toFixed(2)}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {/* Chart */}
          <div className={`h-${isExpanded ? '96' : '64'} w-full`}>
            {activeSensors.length === 0 ? (
              <div className="flex items-center justify-center h-full text-gray-500">
                <div className="text-center">
                  <Layers className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>Select sensors to display</p>
                </div>
              </div>
            ) : chartMode === 'bar' ? (
              <Bar
                ref={chartRef}
                data={chartData}
                options={chartOptions}
              />
            ) : (
              <Line
                ref={chartRef}
                data={chartData}
                options={chartOptions}
              />
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
});

AdvancedChart.displayName = 'AdvancedChart';