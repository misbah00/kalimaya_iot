'use client';

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useMQTTStore } from '@/lib/stores/mqtt-store';
import { 
  Search, 
  Satellite, 
  Clock, 
  TrendingUp, 
  TrendingDown,
  Activity,
  Eye,
  EyeOff,
  Filter
} from 'lucide-react';
import { format } from 'date-fns';

export const SensorList = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showInactive, setShowInactive] = useState(false);
  const [sortBy, setSortBy] = useState<'name' | 'lastUpdate' | 'value'>('lastUpdate');
  
  const { 
    sensors, 
    selectedSensor, 
    setSelectedSensor, 
    removeSensor,
    getSensorStats 
  } = useMQTTStore();

  // Filter and sort sensors
  const filteredSensors = useMemo(() => {
    let filtered = Array.from(sensors.values());
    
    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(sensor =>
        sensor.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Filter inactive sensors
    if (!showInactive) {
      filtered = filtered.filter(sensor => sensor.isActive);
    }
    
    // Sort sensors
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'lastUpdate':
          return b.lastUpdate - a.lastUpdate;
        case 'value':
          return b.lastValue - a.lastValue;
        default:
          return 0;
      }
    });
    
    return filtered;
  }, [sensors, searchTerm, showInactive, sortBy]);

  // Get sensor trend
  const getSensorTrend = (sensor: any) => {
    if (sensor.data.length < 2) return null;
    
    const recent = sensor.data.slice(-2);
    const trend = recent[1].value - recent[0].value;
    
    if (trend > 0) return { icon: TrendingUp, color: 'text-green-500', label: 'up' };
    if (trend < 0) return { icon: TrendingDown, color: 'text-red-500', label: 'down' };
    return { icon: Activity, color: 'text-gray-500', label: 'stable' };
  };

  // Handle sensor click
  const handleSensorClick = (sensorName: string) => {
    if (selectedSensor === sensorName) {
      setSelectedSensor(null);
    } else {
      setSelectedSensor(sensorName);
      // Scroll to chart
      const chartElement = document.getElementById(`chart-${sensorName}`);
      if (chartElement) {
        chartElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  };

  // Handle sensor visibility toggle
  const toggleSensorVisibility = (sensorName: string) => {
    const sensor = sensors.get(sensorName);
    if (sensor) {
      // This would need to be implemented in the store
      console.log('Toggle visibility for:', sensorName);
    }
  };

  return (
    <Card className="h-full shadow-lg">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Satellite className="w-5 h-5 text-primary" />
            Sensor Aktif
            <Badge variant="secondary" className="ml-2">
              {filteredSensors.length}
            </Badge>
          </CardTitle>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowInactive(!showInactive)}
            className="h-8 w-8 p-0"
          >
            <Filter className="w-4 h-4" />
          </Button>
        </div>
        
        {/* Search and Filter */}
        <div className="space-y-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Cari sensor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex gap-2">
            <Button
              variant={sortBy === 'name' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSortBy('name')}
              className="flex-1"
            >
              Nama
            </Button>
            <Button
              variant={sortBy === 'lastUpdate' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSortBy('lastUpdate')}
              className="flex-1"
            >
              Update
            </Button>
            <Button
              variant={sortBy === 'value' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSortBy('value')}
              className="flex-1"
            >
              Nilai
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]">
          <AnimatePresence mode="popLayout">
            {filteredSensors.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="p-6 text-center text-muted-foreground"
              >
                <Satellite className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p className="font-medium">
                  {searchTerm ? 'Tidak ada sensor yang cocok' : 'Belum ada sensor terdeteksi'}
                </p>
                <p className="text-sm mt-1">
                  {searchTerm ? 'Coba kata kunci lain' : 'Menunggu data dari MQTT broker...'}
                </p>
              </motion.div>
            ) : (
              <div className="p-4 space-y-2">
                {filteredSensors.map((sensor) => {
                  const trend = getSensorTrend(sensor);
                  const stats = getSensorStats(sensor.name);
                  const isSelected = selectedSensor === sensor.name;
                  
                  return (
                    <motion.div
                      key={sensor.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.2 }}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Card
                        className={`cursor-pointer transition-all duration-200 ${
                          isSelected 
                            ? 'ring-2 ring-primary shadow-md' 
                            : 'hover:shadow-md'
                        }`}
                        onClick={() => handleSensorClick(sensor.name)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-2">
                                <div
                                  className="w-3 h-3 rounded-full animate-pulse flex-shrink-0"
                                  style={{ backgroundColor: sensor.color }}
                                />
                                <h3 
                                  className="font-semibold truncate"
                                  style={{ color: sensor.color }}
                                >
                                  {sensor.name}
                                </h3>
                                {trend && (
                                  <trend.icon className={`w-4 h-4 ${trend.color} flex-shrink-0`} />
                                )}
                              </div>
                              
                              <div className="space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="text-2xl font-bold text-foreground">
                                    {sensor.lastValue.toFixed(2)}
                                  </span>
                                  <Badge 
                                    variant={sensor.isActive ? 'default' : 'secondary'}
                                    className="text-xs"
                                  >
                                    {sensor.isActive ? 'Aktif' : 'Non-aktif'}
                                  </Badge>
                                </div>
                                
                                {stats && (
                                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                                    <span>Min: {stats.min.toFixed(1)}</span>
                                    <span>Max: {stats.max.toFixed(1)}</span>
                                    <span>Avg: {stats.avg.toFixed(1)}</span>
                                  </div>
                                )}
                                
                                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                  <Clock className="w-3 h-3" />
                                  <span>
                                    {format(sensor.lastUpdate, 'HH:mm:ss')}
                                  </span>
                                </div>
                              </div>
                            </div>
                            
                            <div className="flex flex-col gap-1 ml-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleSensorVisibility(sensor.name);
                                }}
                                className="h-8 w-8 p-0"
                              >
                                {sensor.isActive ? (
                                  <Eye className="w-4 h-4" />
                                ) : (
                                  <EyeOff className="w-4 h-4" />
                                )}
                              </Button>
                              
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  removeSensor(sensor.name);
                                }}
                                className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                              >
                                ×
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </AnimatePresence>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};