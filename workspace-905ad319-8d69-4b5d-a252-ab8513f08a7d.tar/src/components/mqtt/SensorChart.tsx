'use client';

import { useEffect, useRef, memo } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Line, Bar } from 'react-chartjs-2';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useMQTTStore, Sensor } from '@/lib/stores/mqtt-store';
import { 
  Maximize2, 
  Download, 
  Trash2, 
  TrendingUp, 
  TrendingDown,
  Activity
} from 'lucide-react';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface SensorChartProps {
  sensor: Sensor;
  isExpanded?: boolean;
  onExpand?: () => void;
  onExport?: () => void;
  onDelete?: () => void;
}

export const SensorChart = memo<SensorChartProps>(({
  sensor,
  isExpanded = false,
  onExpand,
  onExport,
  onDelete
}) => {
  const chartRef = useRef<any>(null);
  const { chartConfig, getSensorStats, setSelectedSensor } = useMQTTStore();
  
  const stats = getSensorStats(sensor.name);

  // Chart data
  const chartData = {
    labels: sensor.data.map(d => d.formattedTime),
    datasets: [
      {
        label: sensor.name,
        data: sensor.data.map(d => d.value),
        borderColor: sensor.color,
        backgroundColor: chartConfig.chartType === 'area' 
          ? sensor.color + '20' 
          : sensor.color,
        borderWidth: 2,
        fill: chartConfig.chartType === 'area',
        tension: 0.4,
        pointRadius: isExpanded ? 4 : 3,
        pointHoverRadius: 6,
        pointBackgroundColor: sensor.color,
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointStyle: 'circle',
      }
    ]
  };

  // Chart options
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    animation: {
      duration: chartConfig.animationDuration,
    },
    interaction: {
      mode: 'index' as const,
      intersect: false,
    },
    plugins: {
      legend: {
        display: chartConfig.showLegend,
        position: 'top' as const,
        labels: {
          color: sensor.color,
          font: {
            weight: 'bold',
          },
        },
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: sensor.color,
        borderWidth: 1,
        displayColors: false,
        callbacks: {
          label: (context: any) => {
            return `Nilai: ${context.parsed.y.toFixed(2)}`;
          },
        },
      },
    },
    scales: {
      x: {
        display: true,
        grid: {
          display: chartConfig.showGrid,
          color: 'rgba(0, 0, 0, 0.05)',
        },
        ticks: {
          maxTicksLimit: isExpanded ? 10 : 6,
          color: '#666',
        },
      },
      y: {
        display: true,
        grid: {
          display: chartConfig.showGrid,
          color: 'rgba(0, 0, 0, 0.05)',
        },
        ticks: {
          color: '#666',
        },
        beginAtZero: false,
      },
    },
  };

  // Handle chart click
  const handleChartClick = () => {
    setSelectedSensor(sensor.name);
  };

  // Export chart as image
  const exportChart = () => {
    if (chartRef.current) {
      const url = chartRef.current.toBase64Image();
      const link = document.createElement('a');
      link.download = `${sensor.name}-chart-${Date.now()}.png`;
      link.href = url;
      link.click();
    }
    onExport?.();
  };

  // Determine trend
  const getTrend = () => {
    if (!stats || sensor.data.length < 2) return null;
    
    const recent = sensor.data.slice(-2);
    const trend = recent[1].value - recent[0].value;
    
    if (trend > 0) return 'up';
    if (trend < 0) return 'down';
    return 'stable';
  };

  const trend = getTrend();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      whileHover={{ y: -2 }}
      className="h-full"
    >
      <Card className="h-full shadow-lg hover:shadow-xl transition-shadow duration-300">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div 
                className="w-3 h-3 rounded-full animate-pulse"
                style={{ backgroundColor: sensor.color }}
              />
              <CardTitle 
                className="text-lg font-semibold cursor-pointer hover:text-primary transition-colors"
                style={{ color: sensor.color }}
                onClick={handleChartClick}
              >
                {sensor.name}
              </CardTitle>
              {trend && (
                <div className="flex items-center gap-1">
                  {trend === 'up' && (
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  )}
                  {trend === 'down' && (
                    <TrendingDown className="w-4 h-4 text-red-500" />
                  )}
                  {trend === 'stable' && (
                    <Activity className="w-4 h-4 text-gray-500" />
                  )}
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="text-xs">
                {sensor.data.length} data
              </Badge>
              
              <div className="flex gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onExpand}
                  className="h-8 w-8 p-0"
                >
                  <Maximize2 className="w-4 h-4" />
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={exportChart}
                  className="h-8 w-8 p-0"
                >
                  <Download className="w-4 h-4" />
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onDelete}
                  className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
          
          {/* Stats Row */}
          {stats && (
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>Min: {stats.min.toFixed(2)}</span>
              <span>Max: {stats.max.toFixed(2)}</span>
              <span>Avg: {stats.avg.toFixed(2)}</span>
              <span className="font-semibold text-foreground">
                Current: {sensor.lastValue.toFixed(2)}
              </span>
            </div>
          )}
        </CardHeader>
        
        <CardContent className="pt-0">
          <div className={`h-${isExpanded ? '96' : '64'} w-full`}>
            {chartConfig.chartType === 'bar' ? (
              <Bar
                ref={chartRef}
                data={chartData}
                options={chartOptions}
                onClick={handleChartClick}
              />
            ) : (
              <Line
                ref={chartRef}
                data={chartData}
                options={chartOptions}
                onClick={handleChartClick}
              />
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
});

SensorChart.displayName = 'SensorChart';