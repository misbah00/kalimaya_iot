'use client';

import { useEffect, useRef, useCallback } from 'react';
import mqtt, { MqttClient } from 'mqtt';
import { useMQTTStore } from '@/lib/stores/mqtt-store';
import { format } from 'date-fns';

export const useMQTT = () => {
  const clientRef = useRef<MqttClient | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  const {
    mqttConfig,
    connectionStatus,
    setConnectionStatus,
    addSensor,
    updateSensor,
    addNotification
  } = useMQTTStore();

  // Parse sensor name from topic
  const extractSensorName = useCallback((topic: string): string => {
    const parts = topic.split('/');
    return parts[1] || 'unknown';
  }, []);

  // Format sensor data
  const formatSensorData = useCallback((value: number, timestamp?: number) => {
    const ts = timestamp || Date.now();
    return {
      value,
      timestamp: ts,
      formattedTime: format(ts, 'HH:mm:ss')
    };
  }, []);

  // Connect to MQTT broker
  const connect = useCallback(() => {
    if (clientRef.current?.connected) {
      return;
    }

    setConnectionStatus('connecting');
    addNotification('info', 'Menghubungkan ke MQTT broker...');

    try {
      const client = mqtt.connect(mqttConfig.brokerUrl, {
        clientId: mqttConfig.clientId,
        keepalive: mqttConfig.keepalive,
        clean: mqttConfig.clean,
        reconnectPeriod: mqttConfig.reconnectPeriod,
        connectTimeout: mqttConfig.connectTimeout,
      });

      clientRef.current = client;

      // Connection success
      client.on('connect', () => {
        console.log('Connected to MQTT broker');
        setConnectionStatus('connected');
        
        // Subscribe to sensor topic
        client.subscribe(mqttConfig.topic, (err) => {
          if (err) {
            console.error('Subscribe error:', err);
            addNotification('error', 'Gagal subscribe ke topic sensor');
          } else {
            console.log('Subscribed to:', mqttConfig.topic);
            addNotification('success', 'Menunggu data sensor...');
          }
        });
      });

      // Message received
      client.on('message', (topic, message) => {
        try {
          const data = JSON.parse(message.toString());
          const sensorName = extractSensorName(topic);
          
          console.log(`Data received from ${sensorName}:`, data);

          // Validate data
          if (typeof data.value === 'undefined') {
            console.warn('Invalid data format:', data);
            return;
          }

          const sensorData = formatSensorData(data.value, data.ts);

          // Add or update sensor
          const sensors = useMQTTStore.getState().sensors;
          if (!sensors.has(sensorName)) {
            addSensor(sensorName, sensorData);
          } else {
            updateSensor(sensorName, sensorData);
          }

        } catch (error) {
          console.error('Error parsing message:', error);
          addNotification('error', 'Error parsing sensor data');
        }
      });

      // Connection error
      client.on('error', (err) => {
        console.error('MQTT Error:', err);
        setConnectionStatus('error');
        addNotification('error', 'Error koneksi MQTT');
      });

      // Connection close
      client.on('close', () => {
        console.log('MQTT connection closed');
        setConnectionStatus('disconnected');
      });

      // Offline
      client.on('offline', () => {
        console.log('MQTT client offline');
        setConnectionStatus('disconnected');
      });

      // Reconnect
      client.on('reconnect', () => {
        console.log('Reconnecting to MQTT broker...');
        addNotification('info', 'Menghubungkan kembali...');
      });

    } catch (error) {
      console.error('Error connecting to MQTT:', error);
      setConnectionStatus('error');
      addNotification('error', 'Gagal menghubungkan ke MQTT broker');
    }
  }, [mqttConfig, setConnectionStatus, addSensor, updateSensor, addNotification, extractSensorName, formatSensorData]);

  // Disconnect from MQTT broker
  const disconnect = useCallback(() => {
    if (clientRef.current) {
      clientRef.current.end();
      clientRef.current = null;
    }
    
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    
    setConnectionStatus('disconnected');
  }, [setConnectionStatus]);

  // Reconnect with new config
  const reconnect = useCallback(() => {
    disconnect();
    setTimeout(() => {
      connect();
    }, 1000);
  }, [disconnect, connect]);

  // Auto-connect on mount and config change
  useEffect(() => {
    connect();
    
    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  // Manual reconnect when connection is lost
  useEffect(() => {
    if (connectionStatus === 'disconnected' && !clientRef.current?.connected) {
      reconnectTimeoutRef.current = setTimeout(() => {
        connect();
      }, 5000);
    }
    
    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [connectionStatus, connect]);

  // Publish message (for testing)
  const publish = useCallback((topic: string, message: any) => {
    if (clientRef.current?.connected) {
      const payload = JSON.stringify(message);
      clientRef.current.publish(topic, payload, (err) => {
        if (err) {
          console.error('Publish error:', err);
          addNotification('error', 'Gagal mengirim pesan');
        } else {
          console.log('Message published to:', topic);
        }
      });
    } else {
      addNotification('warning', 'Tidak terhubung ke MQTT broker');
    }
  }, [addNotification]);

  // Test functions
  const sendTestData = useCallback((sensorName: string, value?: number) => {
    const testData = {
      value: value || Math.random() * 100,
      ts: Date.now()
    };
    publish(`sensors/${sensorName}/data`, testData);
  }, [publish]);

  const startTestStream = useCallback((sensorNames: string[] = ['temperature', 'humidity', 'pressure']) => {
    sensorNames.forEach(name => {
      const interval = setInterval(() => {
        sendTestData(name, Math.random() * 100);
      }, 2000 + Math.random() * 3000);
      
      // Store interval ID for cleanup
      (window as any).__testIntervals = (window as any).__testIntervals || [];
      (window as any).__testIntervals.push(interval);
    });
    
    addNotification('info', 'Mode testing diaktifkan');
  }, [sendTestData, addNotification]);

  const stopTestStream = useCallback(() => {
    const intervals = (window as any).__testIntervals || [];
    intervals.forEach((interval: NodeJS.Timeout) => clearInterval(interval));
    (window as any).__testIntervals = [];
    addNotification('info', 'Mode testing dihentikan');
  }, [addNotification]);

  return {
    connectionStatus,
    connect,
    disconnect,
    reconnect,
    publish,
    sendTestData,
    startTestStream,
    stopTestStream,
    isConnected: connectionStatus === 'connected',
    isConnecting: connectionStatus === 'connecting',
  };
};