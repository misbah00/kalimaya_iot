#!/bin/bash

# Docker Compose Deployment Script for MQTT Dashboard
# This script manages the Docker Compose deployment

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Configuration
COMPOSE_FILE="docker-compose.yml"
PROJECT_NAME="kalimaya-dashboard"

# Function to check Docker
check_docker() {
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed or not in PATH"
        exit 1
    fi
    
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose is not installed or not in PATH"
        exit 1
    fi
    
    if ! docker info &> /dev/null; then
        log_error "Cannot connect to Docker daemon"
        exit 1
    fi
    
    log_success "Docker and Docker Compose are available"
}

# Function to build images
build_images() {
    log_info "Building Docker images..."
    docker-compose -f $COMPOSE_FILE -p $PROJECT_NAME build
    log_success "Images built successfully"
}

# Function to start services
start_services() {
    local profile=$1
    
    log_info "Starting services..."
    
    if [ -n "$profile" ]; then
        docker-compose -f $COMPOSE_FILE -p $PROJECT_NAME --profile $profile up -d
    else
        docker-compose -f $COMPOSE_FILE -p $PROJECT_NAME up -d
    fi
    
    log_success "Services started successfully"
}

# Function to stop services
stop_services() {
    log_info "Stopping services..."
    docker-compose -f $COMPOSE_FILE -p $PROJECT_NAME down
    log_success "Services stopped successfully"
}

# Function to show access information
show_access_info() {
    log_info "=== Access Information ==="
    echo ""
    
    # Get ports
    local app_port=$(docker-compose -f $COMPOSE_FILE -p $PROJECT_NAME port app | cut -d: -f2)
    
    echo "🌐 Main Application: http://localhost:$app_port"
    echo "📊 MQTT Broker: localhost:1883"
    echo "🔌 WebSocket: ws://localhost:9001"
    echo "💾 Redis: localhost:6379"
    
    echo ""
    echo "📝 To view logs: $0 logs [service]"
    echo "📊 To view status: $0 status"
    echo "🛑 To stop: $0 stop"
}

# Main deployment function
deploy() {
    log_info "Starting Kalimaya Sensor Dashboard Docker deployment..."
    
    check_docker
    build_images
    start_services "$1"
    show_access_info
    
    log_success "🎉 Kalimaya Sensor Dashboard deployed successfully!"
}

# Show usage
usage() {
    echo "Kalimaya Sensor Dashboard Docker Deployment Script"
    echo ""
    echo "Usage: $0 [COMMAND] [OPTIONS]"
    echo ""
    echo "Commands:"
    echo "  deploy [profile]         - Build and start services"
    echo "  start [profile]          - Start services without building"
    echo "  stop                     - Stop all services"
    echo "  status                   - Show service status"
    echo "  logs [service]           - Show logs"
    echo "  help                     - Show this help"
    echo ""
    echo "Profiles:"
    echo "  production               - Enable Nginx reverse proxy"
    echo "  monitoring               - Enable Prometheus and Grafana"
    echo ""
    echo "Examples:"
    echo "  $0 deploy                - Basic deployment"
    echo "  $0 deploy production     - Production deployment with Nginx"
    echo "  $0 deploy monitoring     - With monitoring stack"
    echo "  $0 logs app              - Show app logs"
}

# Main script logic
case "$1" in
    "deploy")
        deploy "$2"
        ;;
    "start")
        check_docker
        start_services "$2"
        show_access_info
        ;;
    "stop")
        stop_services
        ;;
    "status")
        docker-compose -f $COMPOSE_FILE -p $PROJECT_NAME ps
        ;;
    "logs")
        if [ -n "$2" ]; then
            docker-compose -f $COMPOSE_FILE -p $PROJECT_NAME logs -f "$2"
        else
            docker-compose -f $COMPOSE_FILE -p $PROJECT_NAME logs -f
        fi
        ;;
    "help"|"--help"|"-h")
        usage
        ;;
    "")
        usage
        ;;
    *)
        log_error "Unknown command: $1"
        usage
        exit 1
        ;;
esac