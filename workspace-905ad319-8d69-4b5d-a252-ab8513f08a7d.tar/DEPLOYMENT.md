# Kalimaya Sensor Dashboard - Deployment Guide

This guide provides comprehensive instructions for deploying the Kalimaya Sensor Dashboard using Docker and Kubernetes.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Docker Deployment](#docker-deployment)
3. [Kubernetes Deployment](#kubernetes-deployment)
4. [Configuration](#configuration)
5. [Monitoring](#monitoring)
6. [Troubleshooting](#troubleshooting)

## Prerequisites

### For Docker Deployment
- Docker 20.10+
- Docker Compose 2.0+
- At least 4GB RAM
- 10GB free disk space

### For Kubernetes Deployment
- Kubernetes cluster 1.24+
- kubectl configured
- Helm 3.0+ (optional)
- Ingress controller (nginx-ingress recommended)
- Persistent storage provisioner

## Docker Deployment

### Quick Start

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd kalimaya-dashboard
   ```

2. **Deploy with script**
   ```bash
   chmod +x scripts/docker-deploy.sh
   ./scripts/docker-deploy.sh deploy
   ```

3. **Access the application**
   - Main App: http://localhost:3000
   - Sensor Broker: localhost:1883
   - WebSocket: ws://localhost:9001

### Deployment Options

#### Basic Deployment
```bash
./scripts/docker-deploy.sh deploy
```

#### Production Deployment (with Nginx)
```bash
./scripts/docker-deploy.sh deploy production
```

#### With Monitoring Stack
```bash
./scripts/docker-deploy.sh deploy monitoring
```

#### Full Production Setup
```bash
./scripts/docker-deploy.sh deploy production,monitoring
```

### Docker Management Commands

```bash
# View service status
./scripts/docker-deploy.sh status

# View logs
./scripts/docker-deploy.sh logs [service-name]

# Stop services
./scripts/docker-deploy.sh stop

# Restart services
./scripts/docker-deploy.sh restart

# Scale services
./scripts/docker-deploy.sh scale app 3

# Backup data
./scripts/docker-deploy.sh backup

# Restore data
./scripts/docker-deploy.sh restore backup/20231201_120000

# Cleanup everything
./scripts/docker-deploy.sh cleanup
```

## Kubernetes Deployment

### Quick Start

1. **Deploy with script**
   ```bash
   cd k8s
   chmod +x scripts/deploy.sh
   ./scripts/deploy.sh --build
   ```

2. **Check deployment**
   ```bash
   ./scripts/monitor.sh overview
   ```

3. **Access the application**
   ```bash
   ./scripts/port-forward.sh app
   # Then visit http://localhost:3000
   ```

### Step-by-Step Deployment

#### 1. Build and Push Image
```bash
docker build -t mqtt-dashboard:latest .
docker tag mqtt-dashboard:latest your-registry.com/mqtt-dashboard:latest
docker push your-registry.com/mqtt-dashboard:latest
```

#### 2. Update Configuration
Edit `k8s/configmap/configmap.yaml` and `k8s/configmap/secrets.yaml`:
- Update `NEXTAUTH_URL` to your domain
- Change all default secrets and passwords
- Adjust resource limits as needed

#### 3. Deploy Infrastructure
```bash
# Create namespace
kubectl apply -f k8s/namespace/namespace.yaml

# Deploy configurations
kubectl apply -f k8s/configmap/configmap.yaml
kubectl apply -f k8s/configmap/secrets.yaml

# Create storage
kubectl apply -f k8s/deployment/pv.yaml
```

#### 4. Deploy Applications
```bash
# Deploy Redis
kubectl apply -f k8s/deployment/redis.yaml

# Deploy Mosquitto
kubectl apply -f k8s/deployment/mosquitto.yaml

# Deploy main application
kubectl apply -f k8s/deployment/app.yaml
```

#### 5. Create Services and Ingress
```bash
# Create services
kubectl apply -f k8s/service/services.yaml

# Create ingress
kubectl apply -f k8s/ingress/ingress.yaml

# Setup autoscaling
kubectl apply -f k8s/deployment/hpa.yaml
```

### Kubernetes Management Commands

```bash
# View overview
./k8s/scripts/monitor.sh overview

# Check resource usage
./k8s/scripts/monitor.sh resources

# View logs
./k8s/scripts/monitor.sh logs app

# Execute into pod
./k8s/scripts/monitor.sh exec app sh

# Scale deployment
./k8s/scripts/monitor.sh scale mqtt-dashboard 5

# Restart deployment
./k8s/scripts/monitor.sh restart mqtt-dashboard

# Port forwarding
./k8s/scripts/port-forward.sh all
```

## Configuration

### Environment Variables

#### Application Configuration
```yaml
NODE_ENV: "production"
NEXTAUTH_URL: "https://your-domain.com"
NEXTAUTH_SECRET: "your-secret-key"
DATABASE_URL: "file:/app/data/kalimaya.db"
```

#### Sensor Configuration
```yaml
SENSOR_BROKER_URL: "ws://mosquitto:9001/mqtt"
SENSOR_CLIENT_ID_PREFIX: "kalimaya_dashboard"
```

#### Redis Configuration
```yaml
REDIS_URL: "redis://redis:6379"
REDIS_PASSWORD: "your-redis-password"
```

### Security Configuration

#### Production Security Checklist
- [ ] Change all default passwords
- [ ] Use HTTPS with valid certificates
- [ ] Enable authentication for sensor broker
- [ ] Configure firewall rules
- [ ] Set up backup strategy
- [ ] Enable monitoring and alerting
- [ ] Review resource limits

#### SSL/TLS Configuration

For production, update the ingress with proper certificates:

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: mqtt-dashboard-ingress
  annotations:
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
spec:
  tls:
  - hosts:
    - mqtt-dashboard.yourdomain.com
    secretName: mqtt-dashboard-tls
```

## Monitoring

### Docker Monitoring

With the monitoring profile enabled:
- **Grafana**: http://localhost:3001 (admin/admin-change-in-production)
- **Prometheus**: http://localhost:9090

### Kubernetes Monitoring

The application includes built-in metrics:
- Metrics endpoint: `/metrics` (port 9090)
- Health check: `/api/health`

#### Setting up Prometheus

```yaml
# prometheus.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'mqtt-dashboard'
    static_configs:
      - targets: ['mqtt-dashboard-service:9090']
```

#### Key Metrics to Monitor
- CPU and Memory usage
- Request rate and response time
- Error rate
- Active connections
- Database size

## Troubleshooting

### Docker Issues

#### Container Won't Start
```bash
# Check logs
docker-compose logs app

# Check container status
docker-compose ps

# Restart services
docker-compose restart app
```

#### Port Conflicts
```bash
# Check what's using ports
netstat -tulpn | grep :3000

# Stop conflicting services
sudo systemctl stop nginx  # or other conflicting service
```

#### Permission Issues
```bash
# Fix volume permissions
sudo chown -R 1001:1001 ./data
```

### Kubernetes Issues

#### Pod Won't Start
```bash
# Check pod status
kubectl get pods -n mqtt-dashboard

# Describe pod for details
kubectl describe pod <pod-name> -n mqtt-dashboard

# Check logs
kubectl logs <pod-name> -n mqtt-dashboard
```

#### Service Not Accessible
```bash
# Check service endpoints
kubectl get endpoints -n mqtt-dashboard

# Check ingress
kubectl get ingress -n mqtt-dashboard

# Port forward for testing
kubectl port-forward service/mqtt-dashboard-service 3000:80 -n mqtt-dashboard
```

#### Storage Issues
```bash
# Check PVC status
kubectl get pvc -n mqtt-dashboard

# Check storage class
kubectl get storageclass
```

### Common Issues and Solutions

#### 1. Login Not Working
- Check NEXTAUTH_URL configuration
- Verify NEXTAUTH_SECRET is set
- Check session storage (Redis)

#### 2. Sensor Connection Failed
- Verify Mosquitto is running
- Check broker URL configuration
- Ensure firewall allows sensor traffic

#### 3. Database Errors
- Check volume permissions
- Verify storage is mounted
- Check database file integrity

#### 4. High Memory Usage
- Check for memory leaks
- Adjust resource limits
- Review data retention policies

## Performance Optimization

### Docker Optimization
- Use multi-stage builds
- Optimize image size
- Enable health checks
- Set appropriate resource limits

### Kubernetes Optimization
- Use Horizontal Pod Autoscaler
- Set resource requests and limits
- Enable pod disruption budgets
- Use node affinity for better performance

### Application Optimization
- Configure data retention
- Optimize database queries
- Enable caching
- Monitor and tune garbage collection

## Backup and Recovery

### Docker Backup
```bash
# Create backup
./scripts/docker-deploy.sh backup

# Restore backup
./scripts/docker-deploy.sh restore backup/20231201_120000
```

### Kubernetes Backup
```bash
# Backup data
kubectl exec -it deployment/mqtt-dashboard -n mqtt-dashboard -- tar -czf /tmp/backup.tar.gz /app/data
kubectl cp <pod-name>:/tmp/backup.tar.gz ./backup.tar.gz

# Restore data
kubectl cp ./backup.tar.gz <pod-name>:/tmp/backup.tar.gz
kubectl exec -it deployment/mqtt-dashboard -n mqtt-dashboard -- tar -xzf /tmp/backup.tar.gz -C /app/data
```

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review logs for error messages
3. Verify configuration
4. Check resource utilization
5. Consult the documentation

---

**Note**: Always test deployments in a staging environment before deploying to production.