'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Thermometer, Droplets, Waves, AlertTriangle, CheckCircle, Activity, Settings } from 'lucide-react'

interface SensorData {
  temperature: number
  humidity: number
  timestamp: string
  status: 'normal' | 'warning' | 'critical'
}

interface SystemInfo {
  deviceStatus: 'online' | 'offline'
  lastUpdate: string
  uptime: string
  dataPoints: number
}

export default function MonitoringKolamIkan() {
  const [sensorData, setSensorData] = useState<SensorData>({
    temperature: 28.5,
    humidity: 75.2,
    timestamp: new Date().toISOString(),
    status: 'normal'
  })
  
  const [systemInfo, setSystemInfo] = useState<SystemInfo>({
    deviceStatus: 'online',
    lastUpdate: new Date().toISOString(),
    uptime: '2 jam 15 menit',
    dataPoints: 1248
  })

  const [historicalData, setHistoricalData] = useState<SensorData[]>([])
  const [activeTab, setActiveTab] = useState('monitoring')

  // Simulasi data real-time
  useEffect(() => {
    const interval = setInterval(() => {
      const newTemp = 25 + Math.random() * 8
      const newHumidity = 70 + Math.random() * 15
      
      let status: 'normal' | 'warning' | 'critical' = 'normal'
      if (newTemp > 32 || newTemp < 24 || newHumidity > 85 || newHumidity < 65) {
        status = 'warning'
      }
      if (newTemp > 35 || newTemp < 22 || newHumidity > 90 || newHumidity < 60) {
        status = 'critical'
      }

      const newData: SensorData = {
        temperature: parseFloat(newTemp.toFixed(1)),
        humidity: parseFloat(newHumidity.toFixed(1)),
        timestamp: new Date().toISOString(),
        status
      }

      setSensorData(newData)
      setHistoricalData(prev => [...prev.slice(-23), newData])
      setSystemInfo(prev => ({
        ...prev,
        lastUpdate: new Date().toISOString(),
        dataPoints: prev.dataPoints + 1
      }))
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'bg-green-500'
      case 'warning': return 'bg-yellow-500'
      case 'critical': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'normal': return 'Normal'
      case 'warning': return 'Peringatan'
      case 'critical': return 'Kritis'
      default: return 'Tidak Diketahui'
    }
  }

  const SensorCard = ({ 
    title, 
    value, 
    unit, 
    icon: Icon, 
    status, 
    threshold,
    color 
  }: {
    title: string
    value: number
    unit: string
    icon: any
    status: 'normal' | 'warning' | 'critical'
    threshold: { min: number; max: number }
    color: string
  }) => {
    const getCardColor = (status: string) => {
      switch (status) {
        case 'critical': return 'border-red-300 bg-red-50/70'
        case 'warning': return 'border-yellow-300 bg-yellow-50/70'
        default: return 'border-blue-200 bg-blue-50/50'
      }
    }

    const getIconColor = (status: string) => {
      switch (status) {
        case 'critical': return 'text-red-600'
        case 'warning': return 'text-yellow-600'
        default: return 'text-blue-600'
      }
    }

    const isInRange = value >= threshold.min && value <= threshold.max
    const progressPercentage = ((value - threshold.min) / (threshold.max - threshold.min)) * 100

    return (
      <Card className={`border-2 transition-all duration-300 hover:shadow-md ${getCardColor(status)}`}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg bg-white/80 ${getIconColor(status)}`}>
                <Icon className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">{title}</h3>
                <p className="text-sm text-gray-600">Real-time</p>
              </div>
            </div>
            <Badge 
              variant="outline" 
              className={`text-xs font-medium ${
                status === 'normal' ? 'text-green-600 bg-green-50 border-green-200' :
                status === 'warning' ? 'text-yellow-600 bg-yellow-50 border-yellow-200' :
                'text-red-600 bg-red-50 border-red-200'
              }`}
            >
              {status === 'normal' ? 'Normal' : status === 'warning' ? 'Peringatan' : 'Kritis'}
            </Badge>
          </div>

          <div className="space-y-4">
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-bold text-gray-900">{value.toFixed(1)}</span>
              <span className="text-lg text-gray-600">{unit}</span>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs text-gray-600">
                <span>{threshold.min}{unit}</span>
                <span>Optimal: {threshold.min}-{threshold.max}{unit}</span>
                <span>{threshold.max}{unit}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div 
                  className={`h-full transition-all duration-500 rounded-full ${
                    isInRange ? 'bg-green-500' : 'bg-red-500'
                  }`}
                  style={{ 
                    width: `${Math.min(Math.max(progressPercentage, 0), 100)}%` 
                  }}
                />
              </div>
            </div>

            <div className={`text-xs p-2 rounded-md text-center ${
              status === 'normal' ? 'text-green-600 bg-green-50' :
              status === 'warning' ? 'text-yellow-600 bg-yellow-50' :
              'text-red-600 bg-red-50'
            }`}>
              {status === 'normal' && '✓ Kondisi Normal'}
              {status === 'warning' && '⚠ Mendekati Batas Aman'}
              {status === 'critical' && '✕ Diluar Batas Aman'}
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Waves className="h-8 w-8 text-blue-600" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Monitoring Kolam Ikan</h1>
                <p className="text-gray-600">Sistem IoT Berbasis ESP32 & DHT11</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${systemInfo.deviceStatus === 'online' ? 'bg-green-500' : 'bg-red-500'}`} />
                <span>{systemInfo.deviceStatus === 'online' ? 'Online' : 'Offline'}</span>
              </Badge>
              <Button variant="outline" size="sm" onClick={() => setActiveTab('settings')}>
                <Settings className="h-4 w-4 mr-2" />
                Pengaturan
              </Button>
            </div>
          </div>
        </div>

        {/* Alert Section */}
        {sensorData.status !== 'normal' && (
          <Alert className={`border-l-4 ${
            sensorData.status === 'critical' ? 'border-red-500 bg-red-50' : 'border-yellow-500 bg-yellow-50'
          }`}>
            <AlertTriangle className={`h-4 w-4 ${
              sensorData.status === 'critical' ? 'text-red-600' : 'text-yellow-600'
            }`} />
            <AlertTitle className={sensorData.status === 'critical' ? 'text-red-800' : 'text-yellow-800'}>
              {sensorData.status === 'critical' ? 'Kondisi Kritis!' : 'Peringatan'}
            </AlertTitle>
            <AlertDescription className={sensorData.status === 'critical' ? 'text-red-700' : 'text-yellow-700'}>
              {sensorData.status === 'critical' 
                ? 'Suhu atau kelembaban berada di luar batas aman. Segera periksa kondisi kolam!'
                : 'Suhu atau kelembaban mendekati batas aman. Perlu waspada terhadap perubahan kondisi.'
              }
            </AlertDescription>
          </Alert>
        )}

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
            <TabsTrigger value="notifications">Notifikasi</TabsTrigger>
            <TabsTrigger value="settings">Pengaturan</TabsTrigger>
          </TabsList>

          <TabsContent value="monitoring" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Sensor Cards */}
              <div className="lg:col-span-2 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <SensorCard
                    title="Suhu Air"
                    value={sensorData.temperature}
                    unit="°C"
                    icon={Thermometer}
                    status={sensorData.status}
                    threshold={{ min: 24, max: 32 }}
                    color="blue"
                  />
                  <SensorCard
                    title="Kelembaban"
                    value={sensorData.humidity}
                    unit="%"
                    icon={Droplets}
                    status={sensorData.status}
                    threshold={{ min: 65, max: 85 }}
                    color="cyan"
                  />
                </div>

                {/* Chart Placeholder */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Activity className="h-5 w-5" />
                      <span>Grafik Monitoring</span>
                    </CardTitle>
                    <CardDescription>
                      Data sensor 24 jam terakhir
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80 flex items-center justify-center bg-gray-50 rounded-lg">
                      <div className="text-center">
                        <Activity className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600">Grafik monitoring akan ditampilkan di sini</p>
                        <p className="text-sm text-gray-500 mt-2">Memerlukan library chart untuk visualisasi data</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* System Status */}
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Status Koneksi</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className={`h-5 w-5 ${systemInfo.deviceStatus === 'online' ? 'text-green-600' : 'text-red-600'}`}>
                          {systemInfo.deviceStatus === 'online' ? '📡' : '📵'}
                        </div>
                        <div>
                          <p className="text-sm font-medium">ESP32 Device</p>
                          <p className="text-xs text-gray-600">Microcontroller</p>
                        </div>
                      </div>
                      <Badge 
                        variant={systemInfo.deviceStatus === 'online' ? 'default' : 'destructive'}
                        className="text-xs"
                      >
                        {systemInfo.deviceStatus === 'online' ? 'Terhubung' : 'Terputus'}
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="h-5 w-5 text-blue-600">🗄️</div>
                        <div>
                          <p className="text-sm font-medium">ThingSpeak</p>
                          <p className="text-xs text-gray-600">Cloud Platform</p>
                        </div>
                      </div>
                      <Badge variant="default" className="text-xs bg-green-600">
                        Aktif
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="h-5 w-5 text-purple-600">🌡️</div>
                        <div>
                          <p className="text-sm font-medium">DHT11 Sensor</p>
                          <p className="text-xs text-gray-600">Temperature & Humidity</p>
                        </div>
                      </div>
                      <Badge variant="default" className="text-xs bg-green-600">
                        Aktif
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Status Sistem</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Kondisi Saat Ini</span>
                      <Badge className={`${getStatusColor(sensorData.status)} text-white`}>
                        {getStatusText(sensorData.status)}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Update Terakhir</span>
                      <span className="text-sm font-medium">
                        {new Date(systemInfo.lastUpdate).toLocaleTimeString('id-ID')}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Total Data</span>
                      <span className="text-sm font-medium">{systemInfo.dataPoints}</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Informasi Perangkat</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Microcontroller</span>
                      <span className="font-medium">ESP32</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Sensor</span>
                      <span className="font-medium">DHT11</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Platform</span>
                      <span className="font-medium">ThingSpeak</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Uptime</span>
                      <span className="font-medium">{systemInfo.uptime}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="notifications">
            <div className="max-w-4xl mx-auto">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <span>🔔</span>
                    <span>Notifikasi</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-gray-500">
                    <div className="text-4xl mb-3">🔔</div>
                    <p className="text-sm">Sistem notifikasi akan ditampilkan di sini</p>
                    <p className="text-xs text-gray-400 mt-1">Alert untuk kondisi abnormal kolam ikan</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings">
            <div className="max-w-4xl mx-auto">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Settings className="h-5 w-5" />
                    <span>Pengaturan Sistem</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-gray-500">
                    <div className="text-4xl mb-3">⚙️</div>
                    <p className="text-sm">Panel pengaturan akan ditampilkan di sini</p>
                    <p className="text-xs text-gray-400 mt-1">Konfigurasi sensor, notifikasi, dan integrasi</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}