import { NextRequest, NextResponse } from 'next/server'
import { ZAI } from 'z-ai-web-dev-sdk'

interface SensorData {
  temperature: number
  humidity: number
  deviceId: string
  timestamp: string
}

// Simulasi database storage (dalam aplikasi nyata, gunakan database yang sesuai)
let sensorDataStore: SensorData[] = []

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Validasi data yang diterima dari ESP32
    const { temperature, humidity, deviceId } = body
    
    if (typeof temperature !== 'number' || typeof humidity !== 'number') {
      return NextResponse.json(
        { error: 'Invalid sensor data format' },
        { status: 400 }
      )
    }

    if (!deviceId) {
      return NextResponse.json(
        { error: 'Device ID is required' },
        { status: 400 }
      )
    }

    // Validasi range sensor
    if (temperature < -40 || temperature > 80) {
      return NextResponse.json(
        { error: 'Temperature value out of range' },
        { status: 400 }
      )
    }

    if (humidity < 0 || humidity > 100) {
      return NextResponse.json(
        { error: 'Humidity value out of range' },
        { status: 400 }
      )
    }

    // Buat entry data baru
    const newSensorData: SensorData = {
      temperature,
      humidity,
      deviceId,
      timestamp: new Date().toISOString()
    }

    // Simpan ke "database" (dalam real application, gunakan database yang sesuai)
    sensorDataStore.push(newSensorData)

    // Simpan hanya 1000 data terakhir untuk menghemat memori
    if (sensorDataStore.length > 1000) {
      sensorDataStore = sensorDataStore.slice(-1000)
    }

    // Analisis data dengan AI untuk deteksi anomali
    const analysis = await analyzeSensorData(newSensorData, sensorDataStore)

    // Kirim data ke ThingSpeak (simulasi)
    await sendToThingSpeak(newSensorData)

    console.log(`Data received from ESP32 (${deviceId}): Temp=${temperature}°C, Humidity=${humidity}%`)

    return NextResponse.json({
      success: true,
      message: 'Sensor data received successfully',
      data: newSensorData,
      analysis
    })

  } catch (error) {
    console.error('Error processing sensor data:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function GET() {
  try {
    // Kembalikan data sensor terbaru
    const latestData = sensorDataStore.slice(-10) // 10 data terakhir
    
    return NextResponse.json({
      success: true,
      data: latestData,
      total: sensorDataStore.length
    })

  } catch (error) {
    console.error('Error fetching sensor data:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

async function analyzeSensorData(currentData: SensorData, historicalData: SensorData[]) {
  try {
    const zai = await ZAI.create()

    // Ambil 10 data sebelumnya untuk analisis trend
    const recentData = historicalData.slice(-10)
    
    const analysisPrompt = `
    Analisis data sensor berikut untuk kolam ikan:
    
    Data Saat Ini:
    - Suhu: ${currentData.temperature}°C
    - Kelembaban: ${currentData.humidity}%
    - Waktu: ${currentData.timestamp}
    
    Data Historis Terakhir:
    ${recentData.map((data, index) => 
      `${index + 1}. Suhu: ${data.temperature}°C, Kelembaban: ${data.humidity}%`
    ).join('\n')}
    
    Berikan analisis dalam format JSON:
    {
      "status": "normal|warning|critical",
      "trend": "stable|increasing|decreasing|fluctuating",
      "recommendation": "string",
      "riskLevel": "low|medium|high",
      "message": "string"
    }
    
    Pertimbangkan:
    - Suhu optimal untuk kolam ikan: 24-32°C
    - Kelembaban optimal: 65-85%
    - Perubahan drastis dalam waktu singkat
    - Trend perubahan suhu dan kelembaban
    `

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an expert in fish pond monitoring systems. Analyze sensor data and provide JSON-formatted responses.'
        },
        {
          role: 'user',
          content: analysisPrompt
        }
      ],
      temperature: 0.3
    })

    const analysisResult = completion.choices[0]?.message?.content
    
    try {
      return JSON.parse(analysisResult || '{}')
    } catch {
      return {
        status: 'normal',
        trend: 'stable',
        recommendation: 'Monitor continues',
        riskLevel: 'low',
        message: 'Data dalam rentang normal'
      }
    }

  } catch (error) {
    console.error('Error analyzing sensor data:', error)
    return {
      status: 'normal',
      trend: 'stable',
      recommendation: 'Monitor continues',
      riskLevel: 'low',
      message: 'Analisis tidak tersedia'
    }
  }
}

async function sendToThingSpeak(data: SensorData) {
  try {
    // Simulasi pengiriman data ke ThingSpeak
    // Dalam implementasi nyata, gunakan HTTP request ke ThingSpeak API
    
    const thingSpeakData = {
      api_key: process.env.THINGSPEAK_API_KEY,
      field1: data.temperature,
      field2: data.humidity
    }

    console.log('Sending to ThingSpeak:', thingSpeakData)
    
    // Simulasi delay network
    await new Promise(resolve => setTimeout(resolve, 100))
    
    console.log('Data sent to ThingSpeak successfully')
    
  } catch (error) {
    console.error('Error sending to ThingSpeak:', error)
  }
}