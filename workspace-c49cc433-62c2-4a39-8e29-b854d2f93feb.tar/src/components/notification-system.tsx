'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Bell, BellOff, CheckCircle, AlertTriangle, XCircle, Clock } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Notification {
  id: string
  type: 'info' | 'warning' | 'critical'
  title: string
  message: string
  timestamp: string
  read: boolean
}

export function NotificationSystem() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [isMuted, setIsMuted] = useState(false)

  // Simulasi notifikasi masuk
  useEffect(() => {
    const generateNotification = () => {
      const random = Math.random()
      let notification: Notification

      if (random < 0.1) {
        // 10% chance critical alert
        notification = {
          id: Date.now().toString(),
          type: 'critical',
          title: 'Kondisi Kritis!',
          message: 'Suhu kolam melebihi batas aman. Segera lakukan tindakan!',
          timestamp: new Date().toISOString(),
          read: false
        }
      } else if (random < 0.3) {
        // 20% chance warning
        notification = {
          id: Date.now().toString(),
          type: 'warning',
          title: 'Peringatan Suhu',
          message: 'Suhu kolam mendekati batas atas normal. Perlu dipantau.',
          timestamp: new Date().toISOString(),
          read: false
        }
      } else if (random < 0.5) {
        // 20% chance info
        notification = {
          id: Date.now().toString(),
          type: 'info',
          title: 'Sistem Berjalan Normal',
          message: 'Semua sensor berfungsi dengan baik dan data dalam rentang normal.',
          timestamp: new Date().toISOString(),
          read: false
        }
      } else {
        return // No notification
      }

      setNotifications(prev => [notification, ...prev].slice(0, 10))
    }

    const interval = setInterval(generateNotification, 15000) // Setiap 15 detik
    return () => clearInterval(interval)
  }, [])

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === id ? { ...notif, read: true } : notif
      )
    )
  }

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notif => ({ ...notif, read: true }))
    )
  }

  const clearNotification = (id: string) => {
    setNotifications(prev => prev.filter(notif => notif.id !== id))
  }

  const clearAllNotifications = () => {
    setNotifications([])
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'critical':
        return <XCircle className="h-5 w-5 text-red-600" />
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-600" />
      case 'info':
        return <CheckCircle className="h-5 w-5 text-blue-600" />
      default:
        return <Bell className="h-5 w-5 text-gray-600" />
    }
  }

  const getNotificationStyle = (type: string, read: boolean) => {
    const baseStyle = 'p-3 rounded-lg border transition-all duration-200'
    const readStyle = 'bg-gray-50 border-gray-200 opacity-75'
    
    if (read) return `${baseStyle} ${readStyle}`
    
    switch (type) {
      case 'critical':
        return `${baseStyle} bg-red-50 border-red-200 hover:bg-red-100`
      case 'warning':
        return `${baseStyle} bg-yellow-50 border-yellow-200 hover:bg-yellow-100`
      case 'info':
        return `${baseStyle} bg-blue-50 border-blue-200 hover:bg-blue-100`
      default:
        return `${baseStyle} bg-gray-50 border-gray-200 hover:bg-gray-100`
    }
  }

  const unreadCount = notifications.filter(n => !n.read).length

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <CardTitle className="text-lg">Notifikasi</CardTitle>
            {unreadCount > 0 && (
              <Badge variant="destructive" className="text-xs">
                {unreadCount}
              </Badge>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMuted(!isMuted)}
              className="h-8 w-8 p-0"
            >
              {isMuted ? <BellOff className="h-4 w-4" /> : <Bell className="h-4 w-4" />}
            </Button>
            {notifications.length > 0 && (
              <div className="flex space-x-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={markAllAsRead}
                  className="text-xs h-7"
                >
                  Tandai semua
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearAllNotifications}
                  className="text-xs h-7 text-red-600 hover:text-red-700"
                >
                  Hapus semua
                </Button>
              </div>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {notifications.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Bell className="h-12 w-12 mx-auto mb-3 text-gray-300" />
            <p className="text-sm">Tidak ada notifikasi</p>
            <p className="text-xs text-gray-400 mt-1">Notifikasi akan muncul di sini</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className={getNotificationStyle(notification.type, notification.read)}
                onClick={() => markAsRead(notification.id)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3 flex-1">
                    {getNotificationIcon(notification.type)}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <h4 className={cn(
                          'text-sm font-medium truncate',
                          notification.read ? 'text-gray-600' : 'text-gray-900'
                        )}>
                          {notification.title}
                        </h4>
                        {!notification.read && (
                          <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0" />
                        )}
                      </div>
                      <p className={cn(
                        'text-xs mb-2 line-clamp-2',
                        notification.read ? 'text-gray-500' : 'text-gray-700'
                      )}>
                        {notification.message}
                      </p>
                      <div className="flex items-center space-x-2 text-xs text-gray-500">
                        <Clock className="h-3 w-3" />
                        <span>
                          {new Date(notification.timestamp).toLocaleTimeString('id-ID', {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation()
                      clearNotification(notification.id)
                    }}
                    className="h-6 w-6 p-0 ml-2 flex-shrink-0"
                  >
                    <XCircle className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}