'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Wifi, WifiOff, Database, Clock, Activity, RefreshCw } from 'lucide-react'

interface SystemInfo {
  deviceStatus: 'online' | 'offline'
  lastUpdate: string
  uptime: string
  dataPoints: number
}

interface SystemStatusProps {
  systemInfo: SystemInfo
}

export function SystemStatus({ systemInfo }: SystemStatusProps) {
  const handleRefresh = () => {
    window.location.reload()
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Status Koneksi</CardTitle>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleRefresh}
            className="h-8 w-8 p-0"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <div className="flex items-center space-x-3">
            {systemInfo.deviceStatus === 'online' ? (
              <Wifi className="h-5 w-5 text-green-600" />
            ) : (
              <WifiOff className="h-5 w-5 text-red-600" />
            )}
            <div>
              <p className="text-sm font-medium">ESP32 Device</p>
              <p className="text-xs text-gray-600">Microcontroller</p>
            </div>
          </div>
          <Badge 
            variant={systemInfo.deviceStatus === 'online' ? 'default' : 'destructive'}
            className="text-xs"
          >
            {systemInfo.deviceStatus === 'online' ? 'Terhubung' : 'Terputus'}
          </Badge>
        </div>

        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <div className="flex items-center space-x-3">
            <Database className="h-5 w-5 text-blue-600" />
            <div>
              <p className="text-sm font-medium">ThingSpeak</p>
              <p className="text-xs text-gray-600">Cloud Platform</p>
            </div>
          </div>
          <Badge variant="default" className="text-xs bg-green-600">
            Aktif
          </Badge>
        </div>

        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <div className="flex items-center space-x-3">
            <Activity className="h-5 w-5 text-purple-600" />
            <div>
              <p className="text-sm font-medium">DHT11 Sensor</p>
              <p className="text-xs text-gray-600">Temperature & Humidity</p>
            </div>
          </div>
          <Badge variant="default" className="text-xs bg-green-600">
            Aktif
          </Badge>
        </div>

        <div className="pt-3 border-t border-gray-200">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center space-x-2 text-gray-600">
              <Clock className="h-4 w-4" />
              <span>Update Terakhir</span>
            </div>
            <span className="font-medium">
              {new Date(systemInfo.lastUpdate).toLocaleTimeString('id-ID', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
              })}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}