'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

interface SensorCardProps {
  title: string
  value: number
  unit: string
  icon: LucideIcon
  status: 'normal' | 'warning' | 'critical'
  threshold: { min: number; max: number }
  color: 'blue' | 'cyan' | 'green' | 'red' | 'yellow'
}

export function SensorCard({ 
  title, 
  value, 
  unit, 
  icon: Icon, 
  status, 
  threshold,
  color 
}: SensorCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'text-green-600 bg-green-50 border-green-200'
      case 'warning': return 'text-yellow-600 bg-yellow-50 border-yellow-200'
      case 'critical': return 'text-red-600 bg-red-50 border-red-200'
      default: return 'text-gray-600 bg-gray-50 border-gray-200'
    }
  }

  const getCardColor = (color: string, status: string) => {
    const baseColors = {
      blue: 'border-blue-200 bg-blue-50/50',
      cyan: 'border-cyan-200 bg-cyan-50/50',
      green: 'border-green-200 bg-green-50/50',
      red: 'border-red-200 bg-red-50/50',
      yellow: 'border-yellow-200 bg-yellow-50/50'
    }

    if (status === 'critical') return 'border-red-300 bg-red-50/70'
    if (status === 'warning') return 'border-yellow-300 bg-yellow-50/70'
    
    return baseColors[color as keyof typeof baseColors] || baseColors.blue
  }

  const getIconColor = (color: string, status: string) => {
    if (status === 'critical') return 'text-red-600'
    if (status === 'warning') return 'text-yellow-600'
    
    const iconColors = {
      blue: 'text-blue-600',
      cyan: 'text-cyan-600',
      green: 'text-green-600',
      red: 'text-red-600',
      yellow: 'text-yellow-600'
    }
    
    return iconColors[color as keyof typeof iconColors] || iconColors.blue
  }

  const isInRange = value >= threshold.min && value <= threshold.max
  const progressPercentage = ((value - threshold.min) / (threshold.max - threshold.min)) * 100

  return (
    <Card className={cn('border-2 transition-all duration-300 hover:shadow-md', getCardColor(color, status))}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className={cn('p-2 rounded-lg bg-white/80', getIconColor(color, status))}>
              <Icon className="h-6 w-6" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">{title}</h3>
              <p className="text-sm text-gray-600">Real-time</p>
            </div>
          </div>
          <Badge 
            variant="outline" 
            className={cn('text-xs font-medium', getStatusColor(status))}
          >
            {status === 'normal' ? 'Normal' : status === 'warning' ? 'Peringatan' : 'Kritis'}
          </Badge>
        </div>

        <div className="space-y-4">
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-bold text-gray-900">{value.toFixed(1)}</span>
            <span className="text-lg text-gray-600">{unit}</span>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-gray-600">
              <span>{threshold.min}{unit}</span>
              <span>Optimal: {threshold.min}-{threshold.max}{unit}</span>
              <span>{threshold.max}{unit}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
              <div 
                className={cn(
                  'h-full transition-all duration-500 rounded-full',
                  isInRange ? 'bg-green-500' : 'bg-red-500'
                )}
                style={{ 
                  width: `${Math.min(Math.max(progressPercentage, 0), 100)}%` 
                }}
              />
            </div>
          </div>

          {/* Status Message */}
          <div className={cn('text-xs p-2 rounded-md text-center', getStatusColor(status))}>
            {status === 'normal' && '✓ Kondisi Normal'}
            {status === 'warning' && '⚠ Mendekati Batas Aman'}
            {status === 'critical' && '✕ Diluar Batas Aman'}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}