'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Settings, Wifi, Database, Bell, Thermometer, Droplets, Save, RefreshCw } from 'lucide-react'

interface SystemSettings {
  device: {
    deviceId: string
    updateInterval: number
    autoReconnect: boolean
  }
  thresholds: {
    temperature: { min: number; max: number }
    humidity: { min: number; max: number }
  }
  notifications: {
    email: boolean
    push: boolean
    sound: boolean
    emailAddress: string
  }
  thingspeak: {
    apiKey: string
    channelId: string
    enabled: boolean
  }
}

export function SettingsPanel() {
  const [settings, setSettings] = useState<SystemSettings>({
    device: {
      deviceId: 'ESP32_001',
      updateInterval: 5000,
      autoReconnect: true
    },
    thresholds: {
      temperature: { min: 24, max: 32 },
      humidity: { min: 65, max: 85 }
    },
    notifications: {
      email: false,
      push: true,
      sound: true,
      emailAddress: ''
    },
    thingspeak: {
      apiKey: '',
      channelId: '',
      enabled: true
    }
  })

  const [isSaving, setIsSaving] = useState(false)

  const handleSave = async () => {
    setIsSaving(true)
    // Simulasi penyimpanan
    await new Promise(resolve => setTimeout(resolve, 1000))
    setIsSaving(false)
    console.log('Settings saved:', settings)
  }

  const handleReset = () => {
    setSettings({
      device: {
        deviceId: 'ESP32_001',
        updateInterval: 5000,
        autoReconnect: true
      },
      thresholds: {
        temperature: { min: 24, max: 32 },
        humidity: { min: 65, max: 85 }
      },
      notifications: {
        email: false,
        push: true,
        sound: true,
        emailAddress: ''
      },
      thingspeak: {
        apiKey: '',
        channelId: '',
        enabled: true
      }
    })
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Settings className="h-5 w-5" />
            <span>Pengaturan Sistem</span>
          </CardTitle>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" onClick={handleReset}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Reset
            </Button>
            <Button size="sm" onClick={handleSave} disabled={isSaving}>
              <Save className="h-4 w-4 mr-2" />
              {isSaving ? 'Menyimpan...' : 'Simpan'}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="device" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="device">Perangkat</TabsTrigger>
            <TabsTrigger value="thresholds">Batas</TabsTrigger>
            <TabsTrigger value="notifications">Notifikasi</TabsTrigger>
            <TabsTrigger value="thingspeak">ThingSpeak</TabsTrigger>
          </TabsList>

          <TabsContent value="device" className="space-y-4 mt-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="deviceId">ID Perangkat</Label>
                <Input
                  id="deviceId"
                  value={settings.device.deviceId}
                  onChange={(e) => setSettings(prev => ({
                    ...prev,
                    device: { ...prev.device, deviceId: e.target.value }
                  }))}
                  placeholder="ESP32_001"
                />
              </div>
              
              <div>
                <Label htmlFor="updateInterval">Interval Update (ms)</Label>
                <Select
                  value={settings.device.updateInterval.toString()}
                  onValueChange={(value) => setSettings(prev => ({
                    ...prev,
                    device: { ...prev.device, updateInterval: parseInt(value) }
                  }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1000">1 detik</SelectItem>
                    <SelectItem value="5000">5 detik</SelectItem>
                    <SelectItem value="10000">10 detik</SelectItem>
                    <SelectItem value="30000">30 detik</SelectItem>
                    <SelectItem value="60000">1 menit</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Auto Reconnect</Label>
                  <p className="text-sm text-gray-600">Otomatis reconnect jika koneksi terputus</p>
                </div>
                <Switch
                  checked={settings.device.autoReconnect}
                  onCheckedChange={(checked) => setSettings(prev => ({
                    ...prev,
                    device: { ...prev.device, autoReconnect: checked }
                  }))}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="thresholds" className="space-y-4 mt-4">
            <div className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-2 mb-3">
                  <Thermometer className="h-5 w-5 text-blue-600" />
                  <h3 className="font-medium">Batas Suhu (°C)</h3>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="tempMin">Minimum</Label>
                    <Input
                      id="tempMin"
                      type="number"
                      value={settings.thresholds.temperature.min}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        thresholds: {
                          ...prev.thresholds,
                          temperature: { 
                            ...prev.thresholds.temperature, 
                            min: parseFloat(e.target.value) 
                          }
                        }
                      }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="tempMax">Maksimum</Label>
                    <Input
                      id="tempMax"
                      type="number"
                      value={settings.thresholds.temperature.max}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        thresholds: {
                          ...prev.thresholds,
                          temperature: { 
                            ...prev.thresholds.temperature, 
                            max: parseFloat(e.target.value) 
                          }
                        }
                      }))}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2 mb-3">
                  <Droplets className="h-5 w-5 text-cyan-600" />
                  <h3 className="font-medium">Batas Kelembaban (%)</h3>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="humidMin">Minimum</Label>
                    <Input
                      id="humidMin"
                      type="number"
                      value={settings.thresholds.humidity.min}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        thresholds: {
                          ...prev.thresholds,
                          humidity: { 
                            ...prev.thresholds.humidity, 
                            min: parseFloat(e.target.value) 
                          }
                        }
                      }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="humidMax">Maksimum</Label>
                    <Input
                      id="humidMax"
                      type="number"
                      value={settings.thresholds.humidity.max}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        thresholds: {
                          ...prev.thresholds,
                          humidity: { 
                            ...prev.thresholds.humidity, 
                            max: parseFloat(e.target.value) 
                          }
                        }
                      }))}
                    />
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-4 mt-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Notifikasi Push</Label>
                  <p className="text-sm text-gray-600">Notifikasi real-time di browser</p>
                </div>
                <Switch
                  checked={settings.notifications.push}
                  onCheckedChange={(checked) => setSettings(prev => ({
                    ...prev,
                    notifications: { ...prev.notifications, push: checked }
                  }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Notifikasi Email</Label>
                  <p className="text-sm text-gray-600">Kirim alert ke email</p>
                </div>
                <Switch
                  checked={settings.notifications.email}
                  onCheckedChange={(checked) => setSettings(prev => ({
                    ...prev,
                    notifications: { ...prev.notifications, email: checked }
                  }))}
                />
              </div>

              {settings.notifications.email && (
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={settings.notifications.emailAddress}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      notifications: { ...prev.notifications, emailAddress: e.target.value }
                    }))}
                    placeholder="email@example.com"
                  />
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Suara Notifikasi</Label>
                  <p className="text-sm text-gray-600">Mainkan suara untuk alert</p>
                </div>
                <Switch
                  checked={settings.notifications.sound}
                  onCheckedChange={(checked) => setSettings(prev => ({
                    ...prev,
                    notifications: { ...prev.notifications, sound: checked }
                  }))}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="thingspeak" className="space-y-4 mt-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>ThingSpeak Integration</Label>
                  <p className="text-sm text-gray-600">Kirim data ke ThingSpeak platform</p>
                </div>
                <Switch
                  checked={settings.thingspeak.enabled}
                  onCheckedChange={(checked) => setSettings(prev => ({
                    ...prev,
                    thingspeak: { ...prev.thingspeak, enabled: checked }
                  }))}
                />
              </div>

              {settings.thingspeak.enabled && (
                <>
                  <div>
                    <Label htmlFor="apiKey">API Key</Label>
                    <Input
                      id="apiKey"
                      type="password"
                      value={settings.thingspeak.apiKey}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        thingspeak: { ...prev.thingspeak, apiKey: e.target.value }
                      }))}
                      placeholder="Your ThingSpeak API Key"
                    />
                  </div>

                  <div>
                    <Label htmlFor="channelId">Channel ID</Label>
                    <Input
                      id="channelId"
                      value={settings.thingspeak.channelId}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        thingspeak: { ...prev.thingspeak, channelId: e.target.value }
                      }))}
                      placeholder="123456"
                    />
                  </div>

                  <div className="p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Database className="h-4 w-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-900">Field Mapping</span>
                    </div>
                    <div className="text-xs text-blue-700 space-y-1">
                      <div>Field 1: Suhu (°C)</div>
                      <div>Field 2: Kelembaban (%)</div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}