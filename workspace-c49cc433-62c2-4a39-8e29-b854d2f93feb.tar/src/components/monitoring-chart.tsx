'use client'

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

interface SensorData {
  temperature: number
  humidity: number
  timestamp: string
  status: 'normal' | 'warning' | 'critical'
}

interface MonitoringChartProps {
  data: SensorData[]
}

export function MonitoringChart({ data }: MonitoringChartProps) {
  const chartData = data.map((item, index) => ({
    time: new Date(item.timestamp).toLocaleTimeString('id-ID', { 
      hour: '2-digit', 
      minute: '2-digit' 
    }),
    suhu: item.temperature,
    kelembaban: item.humidity,
    status: item.status
  }))

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="text-sm font-medium text-gray-900 mb-2">{`Waktu: ${label}`}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {`${entry.name}: ${entry.value.toFixed(1)}${entry.dataKey === 'suhu' ? '°C' : '%'}`}
            </p>
          ))}
        </div>
      )
    }
    return null
  }

  return (
    <div className="w-full h-80">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={chartData}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis 
            dataKey="time" 
            tick={{ fontSize: 12 }}
            stroke="#6b7280"
          />
          <YAxis 
            yAxisId="temp"
            orientation="left"
            tick={{ fontSize: 12 }}
            stroke="#6b7280"
            label={{ value: 'Suhu (°C)', angle: -90, position: 'insideLeft' }}
          />
          <YAxis 
            yAxisId="humidity"
            orientation="right"
            tick={{ fontSize: 12 }}
            stroke="#6b7280"
            label={{ value: 'Kelembaban (%)', angle: 90, position: 'insideRight' }}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend 
            wrapperStyle={{
              paddingTop: '20px'
            }}
          />
          <Line
            yAxisId="temp"
            type="monotone"
            dataKey="suhu"
            stroke="#3b82f6"
            strokeWidth={2}
            dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
            activeDot={{ r: 6 }}
            name="Suhu Air"
          />
          <Line
            yAxisId="humidity"
            type="monotone"
            dataKey="kelembaban"
            stroke="#06b6d4"
            strokeWidth={2}
            dot={{ fill: '#06b6d4', strokeWidth: 2, r: 4 }}
            activeDot={{ r: 6 }}
            name="Kelembaban"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}